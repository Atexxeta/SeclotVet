class User {
  String userId;
  String walletId;
  String nextOfKin;
  String nextOfKinPhone;
  String firstName;
  String lastName;
  String email;
  String phoneNumber;
  String gender;
  String referralCode;
  String address;
  String middleName;
  String dateJoined;
  String dateOfBirth;
  String referrer;
  String title;
  String userType;
  String companyId;
  String deviceType;
  String identificationCode;
  String photo;
  String idIssueDate;
  String idExpireDate;
  String token;

  User({
    required this.nextOfKin,
    required this.nextOfKinPhone,
    required this.walletId,
    required this.firstName,
    required this.lastName,
    required this.address,
    required this.companyId,
    required this.dateOfBirth,
    required this.dateJoined,
    required this.deviceType,
    required this.email,
    required this.gender,
    required this.userId,
    required this.identificationCode,
    required this.middleName,
    required this.phoneNumber,
    required this.referralCode,
    required this.referrer,
    required this.title,
    required this.photo,
    required this.userType,
    required this.idIssueDate,
    required this.idExpireDate,
    required this.token,
  });

  factory User.fromJson(Map<String, dynamic> parsedJson) {
    User user = User(
      userId: parsedJson["userId"].toString(),
      walletId: parsedJson["walletId"].toString(),
      firstName: parsedJson["firstName"].toString(),
      lastName: parsedJson["lastName"].toString(),
      email: parsedJson["email"].toString(),
      phoneNumber: parsedJson["phoneNumber"].toString(),
      nextOfKin: parsedJson["nextOfKin"].toString(),
      nextOfKinPhone: parsedJson['nextOfKinPhone'].toString(),
      referralCode: parsedJson['referralCode'].toString(),
      userType: parsedJson['userType'].toString(),
      title: parsedJson['title'].toString(),
      referrer: parsedJson['referrer'].toString(),
      middleName: parsedJson['middleName'].toString(),
      gender: parsedJson['gender'].toString(),
      identificationCode: parsedJson['identificationCode'].toString(),
      dateOfBirth: parsedJson['dateOfBirth'].toString(),
      dateJoined: parsedJson['dateJoined'].toString(),
      address: parsedJson['address'].toString(),
      deviceType: parsedJson['deviceType'].toString(),
      companyId: parsedJson['companyId'].toString(),
      photo: parsedJson['photo'].toString(),
      idExpireDate: parsedJson['idExpireDate'].toString(),
      idIssueDate: parsedJson['idIssueDate'].toString(),
      token: parsedJson['token'].toString(),
    );

    return user;
  }

  Map<String, dynamic> toJson() {
    return {
      "userId": this.userId,
      "walletId": this.walletId,
      "firstName": this.firstName,
      "lastName": this.lastName,
      "email": this.email,
      "phoneNumber": this.phoneNumber,
      "companyId": this.companyId,
      "deviceType": this.deviceType,
      "address": this.address,
      "referralCode": this.referralCode,
      "dateOfBirth": this.dateOfBirth,
      "referrer": this.referrer,
      "identificationCode": this.identificationCode,
      "middleName": this.middleName,
      "title": this.title,
      "nextOfKin": this.nextOfKin,
      "nextOfKinPhone": this.nextOfKinPhone,
      "userType": this.userType,
      "gender": this.gender,
      "dateJoined": this.dateJoined,
      "photo": this.photo,
      "idIssueDate": this.idIssueDate,
      "idExpireDate": this.idExpireDate,
      "token": this.token,
    };
  }
}
