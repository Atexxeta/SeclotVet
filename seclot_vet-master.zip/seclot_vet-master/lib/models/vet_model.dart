import 'dart:io';

import 'package:flutter/material.dart';

class VetModel {
  int tenantid;
  String clienId;
  String vetteeLastName;
  String vetteeFirstName;
  String vetteeOtherName;
  String vetServiceID;
  String phoneNumber;
  String picture;
  String email;
  String address;
  String amount;
  String vat;
  String unitUsed;
  String vetteeStatus;
  String vetLatitude;
  String vetLongitude;
  String vetAddress;
  String CouponCode;
  int loginDeviceType;

  VetModel({
    required this.tenantid,
    required this.clienId,
    required this.vetteeFirstName,
    required this.vetteeLastName,
    required this.vetteeOtherName,
    required this.vetServiceID,
    required this.vetteeStatus,
    required this.phoneNumber,
     this.loginDeviceType=1,
     this.picture='',
    required this.email,
    required this.address,
     this.amount='0',
     this.vat='0',
     this.vetAddress='address',
     this.vetLatitude='0',
     this.vetLongitude='0',
     this.CouponCode='0',
     this.unitUsed='',
  });

  factory VetModel.fromJson(Map<String, dynamic> parsedJson) {
    VetModel vetItems = VetModel(
      tenantid: parsedJson["tenantid"],
      loginDeviceType: parsedJson["loginDeviceType"],
      clienId: parsedJson["clienId"].toString(),
      vetteeFirstName: parsedJson["vetteeFirstName"].toString(),
      vetteeLastName: parsedJson["vetteeLastName"].toString(),
      vetteeOtherName: parsedJson["vetteeOtherName"].toString(),
      email: parsedJson["email"].toString(),
      phoneNumber: parsedJson["phoneNumber"].toString(),
      vetLongitude: parsedJson["vetLongitude"].toString(),
      vetLatitude: parsedJson["vetLatitude"].toString(),
      vetteeStatus: parsedJson['vetteeStatus'].toString(),
      address: parsedJson['address'].toString(),
      CouponCode: parsedJson['CouponCode'].toString(),
      vat: parsedJson['vat'],
      vetServiceID: parsedJson['vetServiceID'],
      picture: parsedJson['picture'],
      amount: parsedJson['amount'],
      vetAddress: parsedJson['vetAddress'],
      unitUsed: parsedJson['unitUsed'],
    );

    return vetItems;
  }

  Map<String, dynamic> toJson() {
    return {
      "clienId": this.clienId,
      "tenantid": this.tenantid,
      "loginDeviceType": this.loginDeviceType,
      "vetteeFirstName": this.vetteeFirstName,
      "vetteeOtherName": this.vetteeOtherName,
      "vetteeLastName": this.vetteeLastName,
      "phoneNumber": this.phoneNumber,
      "unitUsed": this.unitUsed,
      "address": this.address,
      "email": this.email,
      "vetAddress": this.vetAddress,
      "vetServiceID": this.vetServiceID,
      "vetteeStatus": this.vetteeStatus,
      "vetLongitude": this.vetLongitude,
      "picture": this.picture,
      "vetLatitude": this.vetLatitude,
      "vat": this.vat,
      "unitUsed": this.unitUsed,
    };
  }
}
