import 'dart:convert';

class PackageModel {
  String id;
  String tenantId;
  String code;
  String name;
  String description;
  String toVetDaysCount;
  String dateCreated;
  String costInUnit;
  String costInAmount;

  PackageModel({
    required this.id,
    required this.tenantId,
    required this.code,
    required this.name,
    required this.description,
    required this.toVetDaysCount,
    required this.dateCreated,
    required this.costInAmount,
    required this.costInUnit,
  });

  factory PackageModel.fromJson(Map<String, dynamic> parsedJson) {
    PackageModel packageModel = PackageModel(
      id: parsedJson["id"].toString(),
      tenantId: parsedJson["tenantId"].toString(),
      code: parsedJson["code"].toString(),
      name: parsedJson["name"].toString(),
      description: parsedJson["description"].toString(),
      toVetDaysCount: parsedJson["toVetDaysCount"].toString(),
      dateCreated: parsedJson['dateCreated'].toString(),
      costInUnit: parsedJson['costInUnit'].toString(),
      costInAmount: parsedJson['costInAmount'].toString(),
    );

    return packageModel;
  }

  Map<String, dynamic> toJson() {
    return {
      "id": this.id,
      "tenantId": this.tenantId,
      "code": this.code,
      "name": this.name,
      "description": this.description,
      "dateCreated": this.dateCreated,
      "toVetDaysCount": this.toVetDaysCount,
      "costInAmount": this.costInAmount,
      "costInUnit": this.costInUnit,
    };
  }
}
