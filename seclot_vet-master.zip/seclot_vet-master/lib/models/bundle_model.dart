import 'dart:convert';

class BundleModel {
  String id;
  String tenantId;
  String code;
  String dateCreated;
  String description;
  String adsPrice;
  String amount;
  String unitCounts;
  String calcType;
  bool isMax;

  BundleModel({
    required this.id,
    required this.tenantId,
    required this.code,
    required this.dateCreated,
    required this.description,
    required this.adsPrice,
    required this.amount,
    required this.calcType,
    required this.unitCounts,
    required this.isMax,
  });

  factory BundleModel.fromJson(Map<String, dynamic> parsedJson) {
    BundleModel bundleModel = BundleModel(
      id: parsedJson["id"].toString(),
      tenantId: parsedJson["tenantId"].toString(),
      code: parsedJson["code"].toString(),
      dateCreated: parsedJson["dateCreated"].toString(),
      description: parsedJson["description"].toString(),
      adsPrice: parsedJson["adsPrice"].toString(),
      amount: parsedJson['amount'].toString(),
      unitCounts: parsedJson['unitCounts'].toString(),
      calcType: parsedJson['calcType'].toString(),
      isMax: parsedJson['isMax'],
    );

    return bundleModel;
  }

  Map<String, dynamic> toJson() {
    return {
      "id": this.id,
      "tenantId": this.tenantId,
      "code": this.code,
      "dateCreated": this.dateCreated,
      "description": this.description,
      "amount": this.amount,
      "adsPrice": this.adsPrice,
      "calcType": this.calcType,
      "unitCounts": this.unitCounts,
      "isMax": this.isMax,
    };
  }
}
