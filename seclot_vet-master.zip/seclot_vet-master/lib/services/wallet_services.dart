import 'package:dio/dio.dart';

import 'api_docs.dart';

class WalletServices{
  static getUserWallet(token,walletId) async {
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.getWallet+'/'+walletId, token: token);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static getUserWalletTransactions(token, userId) async {
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.getWalletTransactionsById + '/' + userId, token: token);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }


  static fundWallet(token,{email,amount,ref,bundleType}) async {
    try {
      var data={
        "email": email,
        "amount": amount,
        "paymentGatewayReference": ref,
        "paymentMethod":"2",
        "bundleType":bundleType,
      };
      print(data);
      Response response = await ApiDocs.makePostRequest(
          url: ApiDocs.fundWallet, token: token,data:data);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }


}