import 'dart:io';
import 'package:dio/dio.dart';

class ApiDocs {
  static const String baseUrl = 'https://api.seclotvet.com/api';
  static const String getUserProfile = '$baseUrl/Account/GetProfile';
  static const String getUpdatedProfile = '$baseUrl/CustomerInformation/GetCustomerByUserId';
  static const String login = '$baseUrl/Token';
  static const String updateProfile = '$baseUrl/Account/UpdateProfile';
  static const String register = '$baseUrl/CustomerInformation/Add';
  static const String changePassword = '$baseUrl/Account/ChangePassword';
  static const String forgotPassword = '$baseUrl/Account/ForgotPassword';
  static const String setNewPassword = '$baseUrl/Account/ResetPassword';
  static const String activate = '$baseUrl/Account/Activate';
  static const String resendOtp = '$baseUrl/resendOtp';
  static const String logoutUrl = '$baseUrl/logout';


  static const String getAllServicePackage = '$baseUrl/VetSetups/GetAllVetService';
  static const String getServicePackageById = '$baseUrl/VetSetups/GetVetService';
  static const String getBundle = '$baseUrl/VetSetups/Get';
  static const String getWallet = '$baseUrl/Payment/GetWallet';
  static const String getWalletTransactionsById = '$baseUrl/Payment/GetUserWalletTrans';
  static const String getVetDone = '$baseUrl/VetTransact/GetVettee';
  static const String getVetByClient = '$baseUrl/VetTransact/GetVetByClient';
  static const String getVetDoneById = '$baseUrl/VetTransact/GetVettee/{GUid}';
  static const String getToBeVet = '$baseUrl/VetTransact/GetVettrans';
  static const String getToBeVetById = '$baseUrl/VetTransact/GetVettrans/{GUid}';


  static const String terminalList = '$baseUrl/Terminal/get';
  static const String addVet = '$baseUrl/VetTransact/AddVettees';
  static const String fundWallet = '$baseUrl/Payment/CreditWallet';
  static const String payFOrVet = '$baseUrl/Payment/ProcessVetPayment';



  static headers(String token) {
    return Options(headers: {
      HttpHeaders.acceptHeader: 'application/json',
      HttpHeaders.authorizationHeader: 'Bearer $token',
    });
  }

  static Dio getHttp() {
    Dio dio;
    dio = new Dio();
    return dio;
  }

  static makePostRequest({url, data, token}) async {
    var headers = ApiDocs.headers(token ??
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEiLCJuYW1lIjoiYWRtaW5pc3RyYXRvckBsbWUuY29tIiwiZW1haWwiOiJhZG1pbmlzdHJhdG9yQGxtZS5jb20iLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiIxIiwibmJmIjoxNjI4NTI4Njg3LCJleHAiOjE2Mjg3MDg2ODcsImlzcyI6IlNIQi5BcGkiLCJhdWQiOiJTSEIuV2ViIn0.nta8QPVg-wUFDSLk6UgYjb3757w_YRi-ux8YsT5KLd8');

    print(url);
    return await ApiDocs.getHttp().post(url, data: data, options: headers);
  }

  static makePutRequest({url, data, token}) async {
    var headers = ApiDocs.headers(token ??
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEiLCJuYW1lIjoiYWRtaW5pc3RyYXRvckBsbWUuY29tIiwiZW1haWwiOiJhZG1pbmlzdHJhdG9yQGxtZS5jb20iLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiIxIiwibmJmIjoxNjI4NTI4Njg3LCJleHAiOjE2Mjg3MDg2ODcsImlzcyI6IlNIQi5BcGkiLCJhdWQiOiJTSEIuV2ViIn0.nta8QPVg-wUFDSLk6UgYjb3757w_YRi-ux8YsT5KLd8');
    print(url);
    return await ApiDocs.getHttp().put(url, data: data, options: headers);
  }

  static makeGetRequest({url, data, token}) async {
    var headers = ApiDocs.headers(token);
    print(url);

    return await ApiDocs.getHttp()
        .get(url, queryParameters: data, options: headers);
  }


  static handleErrors(e) {
    if (e is DioError) {
      if (e.response != null &&
          e.response!.statusCode != null &&
          e.response!.statusCode == 401) {
        // Get.offNamedUntil(Routes.signIn, (route) => false);
      }
      if (e.type == DioErrorType.response) {
        if (e.response!.data is String) {
          return e.response!.data;
        }

        return e.response!.data['errors'] != null
            ? e.response!.data['errors'][0]
            : e.response!.data['message'];
      } else if (e.type == DioErrorType.other) {
        return e.error != null ? e.error.toString() : e.message;
      } else {
        // Something happened in setting up or sending the request that triggered an Error
        return e.message;
      }
    } else {
      print(e);
      return e.toString();
    }
  }

  static isRequestSuccessful(int? statusCode) {
    return statusCode! >= 200 && statusCode < 300;
  }
}
