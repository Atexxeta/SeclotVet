import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'api_docs.dart';

class VetServices {
  static submitVets({
    @required id,
    @required token,
    @required clientId,
    @required tenantId,
    @required serviceId,
    @required vetteeListID,
    @required lastName,
    @required firstName,
    @required otherName,
    @required picture,
    @required phone,
    @required email,
    @required address,
    @required vetcity,
  }) async {
    var data = {
      "tenantId": 13,
      "clientId": clientId,
      "vetteeLastName": lastName,
      "vetteeFirstName": firstName,
      "vetteeOtherName": otherName,
      "vetServiceID": serviceId,
      "phoneNumber": phone,
      "vetcity": int.parse(vetcity),
      "email": email,
      "address": address,
      "amount": 0,
      "vat": 0,
      "unitUsed": 0,
      "vetteeStatus": 0,
      "loginDeviceType": Platform.isIOS ? 2 : 1,
      "paymentMethod": 0,
      "paymentStatus": 0,
      "vetAddress": "  ",
      "vetLatitude": 0,
      "vetLongitude": 0,
      "CouponCode": " "
    };
    print(picture);
    print(data);
    if (picture != null){
      data['picture'] =
          'data:image/png;base64,' + base64Encode(picture.readAsBytesSync());}

    print('=======>data');
    print(data);
    try {
      Response response = await ApiDocs.makePostRequest(
          url: ApiDocs.addVet , token: token, data: data);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static payFOrVet({
    @required refCodes,
    @required token,
  }) async {
    try {
      Response response = await ApiDocs.makePostRequest(
          url: ApiDocs.payFOrVet, token: token, data: refCodes);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }
}
