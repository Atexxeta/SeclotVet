import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:intl/intl.dart';

import 'api_docs.dart';

class UserServices {
  static updateUser({
    required String idIssueDate,
    required String idExpireDate,
    required String firstName,
    required String lastName,
    required String phoneNumber,
    required String gender,
    required String email,
    required String address,
    required String locationid,
    required String dateOfBirth,
    required String identificationCode,
    required String identificationType,
    required String userId,
    required picture,
    required photoId,
    required String token,
  }) async {
    print(picture);
    print(photoId);
    var data = {
      "userId": userId,
      "firstName": firstName,
      "lastName": lastName,
      "email": email,
      "phoneNumber": phoneNumber,
      "address": address,
      "locationid": locationid,
      "deviceType": (Platform.isIOS == true) ? 2 : 1,
      "idIssueDate": idIssueDate,
      "idExpireDate": idExpireDate,
      "identificationCode": identificationCode,
      "identificationType": identificationType
              .toLowerCase()
              .replaceAll(' ', '')
              .contains('Passport')
          ? '1'
          : identificationType
                  .toLowerCase()
                  .replaceAll(' ', '')
                  .contains('Driver License')
              ? '2'
              : identificationType
                      .toLowerCase()
                      .replaceAll(' ', '')
                      .contains('National ID')
                  ? '3'
                  : identificationType
                          .toLowerCase()
                          .replaceAll(' ', '')
                          .contains('Social Security')
                      ? '4': identificationType
                          .toLowerCase()
                          .replaceAll(' ', '')
                          .contains('Voter\'s Card')
                      ? '6'
                      : '5',
      "locationId": 0,
      "createdTime": DateFormat('yyyy-MM-dd').format(DateTime.now()).toString(),
      "dateOfBirth": dateOfBirth,
      "gender": gender == 'Male' ? '0' : '1',
    };
    if (picture != null){
      data['photo'] =
          'data:image/png;base64,' + base64Encode(picture.readAsBytesSync());}
    if (photoId != null){
      data['identityPhoto'] =
          'data:image/png;base64,' + base64Encode(photoId.readAsBytesSync());}
    print(data);

    try {
      Response response = await ApiDocs.makePostRequest(
          url: ApiDocs.updateProfile, data: data, token: token);
      print('update user');

      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      print(e);
      return ApiDocs.handleErrors(e);
    }
  }

  static resetPassword({required email}) async {
    try {
      var data = {
        'usernameOrEmail': email,
      };
      Response response = await ApiDocs.makePostRequest(
          url: ApiDocs.forgotPassword + '/' + email, data: data);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static changePassword(
      {required currentPassword,
      required newPassword,
      required confirmPassword,
      token}) async {
    var data = {
      'currentPassword': currentPassword,
      'newPassword': newPassword,
      'confirmPassword': confirmPassword,
    };
    print(data);

    try {
      Response response = await ApiDocs.makePostRequest(
          url: ApiDocs.changePassword, data: data, token: token);
      print('changePassword');

      if (ApiDocs.isRequestSuccessful(response.statusCode)) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static setNewPassword(
      {required password, required email, required code, token}) async {
    var data = {
      'newPassword': password,
      'code': code,
      'userNameOrEmail': email,
    };
    print(data);

    try {
      Response response = await ApiDocs.makePostRequest(
          url: ApiDocs.setNewPassword, data: data, token: token);
      print('changePassword');

      if (ApiDocs.isRequestSuccessful(response.statusCode)) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static getUpdateProfile(token, userId) async {
    print(token);
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.getUpdatedProfile + '/' + userId, token: token);
      print('profile');
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      print(e.toString());
      return ApiDocs.handleErrors(e);
    }
  }
}
