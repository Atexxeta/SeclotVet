import 'package:dio/dio.dart';

import 'api_docs.dart';

class WebServices {
  static getAllServicePackages(token) async {
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.getAllServicePackage, token: token);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static getAllTerminals(token) async {
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.terminalList, token: token);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static getServicePackageByIds(token, id) async {
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.getServicePackageById + '/' + id, token: token);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static getBundle(token) async {
    try {
      Response response =
          await ApiDocs.makeGetRequest(url: ApiDocs.getBundle, token: token);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static gePendingVets(token) async {
    try {
      Response response =
          await ApiDocs.makeGetRequest(url: ApiDocs.getToBeVet, token: token);
      print(response);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static getVetsDone(token) async {
    try {
      Response response =
          await ApiDocs.makeGetRequest(url: ApiDocs.getVetDone, token: token);

      if (response.statusCode == 200) {
        print('response');
        print(response.data);

        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static getVets(token, id) async {
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.getVetByClient + '/' + '$id',
          token: token,
      )
      ;

      if (response.statusCode == 200) {
        print('response');
        print(response.data);

        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }
}
