import 'dart:io';

import 'package:dio/dio.dart';
import 'api_docs.dart';

class AuthenticationService {
  static login({email, password}) async {
    try {
      var data = {
        'username': email,
        'password': password,
      };
      print(data);
      Response response =
          await ApiDocs.makePostRequest(url: ApiDocs.login, data: data);
      print('login');
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      print(e.toString());
      return ApiDocs.handleErrors(e);
    }
  }

  static getProfile(token) async {
    print(token);
    try {
      Response response = await ApiDocs.makeGetRequest(
          url: ApiDocs.getUserProfile, token: token);
      print('profile');
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static register({
    required String customerEmail,
    required String customerPhone,
    required String customerFirstName,
    required String customerLastName,
    required String password,
    required String confirmPassword,
  }) async {
    var data = {
      'customerEmail': customerEmail,
      'customerPhone': customerPhone,
      'customerFirstName': customerFirstName,
      'customerLastName': customerLastName,
      'password': password,
      'confirmPassword': confirmPassword,
      'tenantId': 13,
      'roleId': 30,
      'deviceType': (Platform.isIOS == true) ? 2 : 1,
    };
    print(data);
    try {
      Response response =
          await ApiDocs.makePostRequest(url: ApiDocs.register, data: data);
      print('register');
      print(response);

      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }


  static activatedUser(
      {required String usernameOrEmail, required String activationCode}) async {
    try {
      var data = {
        'usernameOrEmail': usernameOrEmail,
        'activationCode': activationCode,
      };
      print(data);
      Response response =
          await ApiDocs.makePutRequest(url: ApiDocs.activate, data: data);
      print('activate');
      print(response);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  static resendOtp(email) async {
    try {
      var data = {
        'email': email,
      };
      print(data);
      Response response =
          await ApiDocs.makePostRequest(url: ApiDocs.resendOtp, data: data);
      if (response.statusCode == 200) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }

  // + '/' + email

  static logout({token}) async {
    try {
      Response response =
          await ApiDocs.makePostRequest(url: ApiDocs.logoutUrl, token: token);

      if (ApiDocs.isRequestSuccessful(response.statusCode)) {
        return response.data;
      } else {
        return '${response.statusCode} - ${response.statusMessage}';
      }
    } on DioError catch (e) {
      return ApiDocs.handleErrors(e);
    }
  }
}
