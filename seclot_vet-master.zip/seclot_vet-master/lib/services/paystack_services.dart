import 'dart:convert';
import 'package:http/http.dart' as http;

class PaystackConst {
  static var paystackTokenTest =
      'sk_live_41b923f9a77e4b36ef9d3b4dda728ee14f384b0e';
  static var publicKeyTest = 'pk_live_0ca676ff12a7e5904198378edbf52b70f8c05c59';

  // "testSecret": "sk_test_d95f80c4e7cc4c98ea0051e5af80c2a3b0f366ea"
  // "liveSecret": "sk_live_41b923f9a77e4b36ef9d3b4dda728ee14f384b0e"
}

class PaymentServices {
  static createPayStackAccessCode(email, amount) async {
    Map data = {"amount": amount, "email": email};
    var url = Uri.parse('https://api.paystack.co/transaction/initialize');
    var response = await http.post(
      url,
      body: data,
      headers: {
        'Authorization': 'Bearer ${PaystackConst.paystackTokenTest}',
      },
    );
    print('payStack response');
    print(response.body);
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      return '${response.statusCode} - ${response.reasonPhrase}';
    }
  }
}
