import 'package:get/get.dart';
import 'package:seclot_vet/models/package_model.dart';
import 'package:seclot_vet/services/web_services.dart';

class PackageController extends GetxController {
  List<PackageModel> packages=[];


  getAllPackages(token) async {
    if(packages.isEmpty) {
      var data = await WebServices.getAllServicePackages(token);
      print(data);
      if (data['shortDescription'] != 'SUCCESS') {
        print('error fetching packages');
        packages = [];
      } else {
        packages = data['object']['items']
            .map<PackageModel>((json) => PackageModel.fromJson(json))
            .toList();
      }
    }
    return packages;
  }


}
