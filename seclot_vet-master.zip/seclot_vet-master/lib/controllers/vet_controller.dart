import 'package:get/get.dart';
import 'package:seclot_vet/services/web_services.dart';

class VetController extends GetxController {
  var terminalList;

  getAllTerminals(token) async {
    if (terminalList == null) {
      var data = await WebServices.getAllTerminals(token);
      print(data);
      if (data['shortDescription'] != 'SUCCESS') {
        print('Error fetching terminals');
        terminalList = [];
      } else {
        terminalList = data['object']['items'];
      }
    }
    return terminalList;
  }
}
