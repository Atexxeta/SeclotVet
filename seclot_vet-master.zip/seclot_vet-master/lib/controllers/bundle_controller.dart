import 'package:get/get.dart';
import 'package:seclot_vet/models/bundle_model.dart';
import 'package:seclot_vet/services/web_services.dart';

class BundleController extends GetxController {
  List<BundleModel> bundles=[];


  getBundles(token) async {
    var data = await WebServices.getBundle(token);

    print(data);
    if(data['code']!='200'){
      Get.back();

      bundles = [];
    } else {
      bundles = data['object']['items']
          .map<BundleModel>((json) => BundleModel.fromJson(json))
          .toList();
    }

    return bundles;
  }
}
