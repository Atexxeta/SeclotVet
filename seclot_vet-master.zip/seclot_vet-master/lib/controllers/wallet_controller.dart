import 'package:get/get.dart';
import 'package:seclot_vet/services/wallet_services.dart';

class WalletController extends GetxController {
  var wallet;

  getWallet(token,walletId) async {
    var data = await WalletServices.getUserWallet(token,walletId);
    print(data);
    if (data['shortDescription'] !='SUCCESS') {
      print('......=>');
      print(data['shortDescription']);
      wallet = '0.0';
    } else {
      wallet =data['object'];
    }

    return wallet;
  }
}