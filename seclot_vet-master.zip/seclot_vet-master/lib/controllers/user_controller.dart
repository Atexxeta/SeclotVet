import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:seclot_vet/services/auth_services.dart';

import '../models/user_model.dart';
import '../routes.dart';

class UserController extends GetxController {
  String token = '';
  var user;
  bool internetStatus = true;

  String getToken() {
    return token;
  }

  User getUser() {
    return user;
  }

  void logOut({token}) {
    Get.offNamedUntil(Routes.signIn, (route) => false);
    AuthenticationService.logout();
    user  = null;
  }

  setInternetStatus(bool currentStatus) {
    this.internetStatus = currentStatus;
    update();
  }

  setUserDetails(Map response, {bool setToken: false}) async {
    user = User.fromJson(response['object']);
    if (setToken) this.token = token;
    this.user = user;
  }

  setToken(token, {bool setToken: true}) {
    if (setToken) this.token = token;
    this.user = user;
  }


  getLogo() {
    String seclotLogo ='https://vet.seclot.com/assets/img/logo.png';
    return seclotLogo;
  }


  pickDate(context, title) {
    return showDatePicker(
        context: context,
        fieldHintText: title,
        initialDate: DateTime.now(),
        initialDatePickerMode: DatePickerMode.year,
        firstDate: DateTime(
            DateTime.now().year - 5, DateTime.now().month, DateTime.now().day),
        lastDate:  DateTime(
            DateTime.now().year + 4, DateTime.now().month, DateTime.now().day));
  }


  pickDob(context, title) {
    return showDatePicker(
        context: context,
        fieldHintText: title,
        initialDate: DateTime.now(),
        initialDatePickerMode: DatePickerMode.year,
        firstDate: DateTime(
            DateTime.now().year - 70, DateTime.now().month, DateTime.now().day),
        lastDate:  DateTime.now());
  }
}
