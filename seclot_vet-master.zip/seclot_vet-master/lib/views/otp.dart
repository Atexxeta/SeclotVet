import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/services/auth_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import '../../../routes.dart';
import 'input_fields.dart';
import 'login_screen.dart';

class OtpScreen extends StatefulWidget {
  @override
  _OtpScreenState createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController otpController = TextEditingController();

  TextEditingController textEditingController = TextEditingController();
  String pin = '';

  @override
  void initState() {
    var arg = Get.arguments;
    print(arg);
    if (arg != null) {
      if (arg['email'].length > 4) {
        setState(() {
          email = arg['email'];
          phone = arg['phone'];
          password = arg['password'];
        });
      } else
        email = 'info@seclot.com';
    } else
      email = 'info@seclot.com';
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  String email = '';
  String phone = '';
  String otp = '';
  String password = '';



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.west,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                    ),
                    Text(''),
                    SizedBox(width: 30),
                  ],
                ),
              ),
              Image.asset(
                'assets/images/seclot_logo.png',
                width: MediaQuery.of(context).size.width * 0.28,
              ),
              SizedBox(height: 25),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 20, 0, 25),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Activate Account',
                        style: GoogleFonts.roboto(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                    Text(
                      'Activate your account with the OTP sent to your email',
                      style: GoogleFonts.roboto(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(30))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 15.0, vertical: 15),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 30,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(25.0),
                            child: InputFormField(
                              enabled: !isLoading,
                              controller: otpController,
                              obscure: false,
                              label: 'OTP',
                              textCapitalization:
                              TextCapitalization.none,

                              validator: (value) {
                                if (value.isEmpty) {
                                  return "Please enter an OTP";
                                }
                                return null;
                              },
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 25.0),
                            child: Column(
                              children: [
                                SizedBox(
                                    height: MediaQuery.of(context).size.height *
                                        0.13),
                                Buttons.authButton(
                                    context: context,
                                    title:
                                        isLoading ? 'Loading...' : 'Activate',
                                    onTap: () {
                                      veryOtp();
                                      // Get.toNamed(Routes.signUp3, arguments: {'email': email,'phone': phone});
                                    }),
                                SizedBox(
                                  height: 20,
                                ),
                                InkWell(
                                  onTap: () {
                                    resendOtp();
                                  },
                                  child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'Resend OTP',
                                        style: TextStyle(
                                          letterSpacing: 0.8,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w500,
                                          color: Theme.of(context).primaryColor,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool isLoading = false;

  changeLoadingState() {
    setState(() {
      isLoading = !isLoading;
    });
  }


  veryOtp() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      changeLoadingState();
      var response = await AuthenticationService.activatedUser(
          activationCode: otpController.text, usernameOrEmail: email);
      print(response);
      if (response['shortDescription']!='SUCCESS') {
        Dialogs.showErrorSnackBar('Error', response['shortDescription']);        changeLoadingState();

      } else {
        changeLoadingState();
        signIn();
        Dialogs.showSuccessSnackBar('Success', 'OTP accepted');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'Error', 'Ensure all required fields are filled correctly');
    }
  }

  resendOtp() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      changeLoadingState();
      var response = await AuthenticationService.resendOtp(email);
      print(response);
      if (response['shortDescription']!='SUCCESS') {
        changeLoadingState();
        Dialogs.showErrorSnackBar('Error', response['shortDescription']);
      } else {
        changeLoadingState();
        Dialogs.showSuccessSnackBar('Success', 'OTP resent to your email');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'Error', 'Ensure all required fields are filled correctly');
    }
  }

  UserController userController = Get.put(UserController(), permanent: true);

  signIn() async {
    if (await InternetUtils.checkConnectivity()) {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        setState(() {
          isLoading = true;
        });
        var response =
            await AuthenticationService.login(email: email, password: password);
        if (response is String) {
          changeLoadingState();
          Get.offAll(() => LogInScreen());
        } else {
          var token = response['object']['token'];
          await userController.setToken(token);

          var profile = await AuthenticationService.getProfile(token);

          if (profile is String) {
            changeLoadingState();

            Dialogs.showErrorSnackBar('Error!', profile);
          } else if (response['code'] != '200') {
            Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
          } else {
            Get.offNamedUntil(
                Routes.dashboard, (Route<dynamic> route) => false);

            await userController.setUserDetails(profile);
            Dialogs.showNoticeSnackBar(
                'Congratulation!', 'Welcome ${profile['object']['firstName']}');
          }
        }
      } else {
        Dialogs.showErrorSnackBar(
            'Error', 'Please enter valid email & password');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'No Internet!', 'Please check your internet connection.');
    }
    setState(() {
      isLoading = false;
    });
  }
}
