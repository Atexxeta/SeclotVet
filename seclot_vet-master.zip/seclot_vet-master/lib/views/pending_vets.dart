import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/controllers/wallet_controller.dart';
import 'package:seclot_vet/services/vet_services.dart';
import 'package:seclot_vet/services/web_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import 'homepage.dart';
import 'vetting_screen.dart';

class PendingVetScreen extends StatefulWidget {
  const PendingVetScreen({Key? key}) : super(key: key);

  @override
  _PendingVetScreenState createState() => _PendingVetScreenState();
}

class _PendingVetScreenState extends State<PendingVetScreen> {
  UserController userController = Get.find();
  String token = '';
  String clientId = '';
  String walletId = '';
  double balance = 0.0;

  List refCodes = [];
  var allVet;
  var pendingVet;
  var totalNumber;
  var vipNumber;
  var basicNumber;
  var standardNumber;
  var premiumNumber;
  var totalUnit;
  var vipUnit;
  var basicUnit;
  var standardUnit;
  var premiumUnit;
  WalletController walletController = Get.put(WalletController());

  @override
  void initState() {
    token = userController.getToken();
    clientId = userController.getUser().userId;
    walletId = userController.getUser().walletId.toString();

    boot();
    super.initState();
  }

  boot() async {
    var walletDetail = await walletController.getWallet(token, walletId);
    setState(() {
      balance = walletDetail['balance'] ?? 0.0;
    });
    getVets();
  }

  getVets() async {
    var response = await WebServices.getVets(token, clientId);
    // print(response);
    if (response['shortDescription'] != 'SUCCESS') {
      Dialogs.showErrorSnackBar('Error Fetching', response);
    } else {
      setState(() {
        allVet = response['object']['items'];
        print(allVet.length);
        filter();
      });
    }
  }

  filter() {
    pendingVet = allVet
        .where((i) => i['paymentStatus'] == 0 && i['paymentStatus'] != null)
        .toList();
    var premiumVet = pendingVet
        .where((i) => i['vetServiceID'] == 6 && i['vetServiceID'] != null)
        .toList();
    var basicVet = pendingVet
        .where((i) => i['vetServiceID'] == 4 && i['vetServiceID'] != null)
        .toList();
    var standardVet = pendingVet
        .where((i) => i['vetServiceID'] == 5 && i['vetServiceID'] != null)
        .toList();
    var vipVet = pendingVet
        .where((i) => i['vetServiceID'] == 7 && i['vetServiceID'] != null)
        .toList();

    print('pendingVet.length');
    print(pendingVet.length);

    setState(() {
      totalNumber = pendingVet.length;
      vipNumber = vipVet.length;
      standardNumber = standardVet.length;
      basicNumber = basicVet.length;
      premiumNumber = premiumVet.length;
      vipUnit = int.parse(vipNumber.toString()) * 8;
      premiumUnit = int.parse(premiumNumber.toString()) * 4;
      basicUnit = int.parse(basicNumber.toString()) * 1;
      standardUnit = int.parse(standardNumber.toString()) * 2;
      totalUnit = vipUnit + premiumUnit + basicUnit + standardUnit;
    });
  }

//unitUsed
  // vetServiceID

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Column(
        children: [
          // SizedBox(height: 50),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                ),
                Text(''),
                SizedBox(width: 30),
              ],
            ),
          ),

          SizedBox(height: 10),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(30.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 5, 0, 10),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: Text(
                              'Vetting Summary',
                              style: GoogleFonts.roboto(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                          Text(
                            'Your vetting is awaiting payment',
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.black),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(20, 0, 15, 0),
                          child: Column(
                            children: [
                              SizedBox(height: 15),
                              Expanded(
                                child: pendingVet == null
                                    ? Center(
                                        child: CircularProgressIndicator(
                                        color: Theme.of(context).primaryColor,
                                      ))
                                    : Container(
                                        child: SingleChildScrollView(
                                        child: Column(children: [
                                          Container(
                                            height: 1,
                                            child: ListView.builder(
                                                padding: EdgeInsets.all(0),
                                                physics:
                                                    NeverScrollableScrollPhysics(),
                                                itemCount: pendingVet.length,
                                                itemBuilder: (context, index) {
                                                  var item = pendingVet[index];
                                                  refCodes.add(
                                                      item['referenceCode']);
                                                  print(refCodes);
                                                  return Container();
                                                }),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text('VIP',
                                                            style:
                                                                buildTextStyle()),
                                                        SizedBox(height: 8),
                                                        Text(
                                                            '$vipNumber Person(s)',
                                                            style:
                                                                subTextStyle()),
                                                      ],
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Text(
                                                        '${int.parse(vipNumber.toString()) * 8} unit(s)',
                                                        style: subTextStyle()),
                                                  ),
                                                ]),
                                          ),
                                          Divider(),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text('PREMIUM',
                                                            style:
                                                                buildTextStyle()),
                                                        SizedBox(height: 8),
                                                        Text(
                                                            '$premiumNumber Person(s)',
                                                            style:
                                                                subTextStyle()),
                                                      ],
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Text(
                                                        '${int.parse(premiumNumber.toString()) * 4} unit(s)',
                                                        style: subTextStyle()),
                                                  ),
                                                ]),
                                          ),
                                          Divider(),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text('STANDARD',
                                                            style:
                                                                buildTextStyle()),
                                                        SizedBox(height: 8),
                                                        Text(
                                                            '$standardNumber Person(s)',
                                                            style:
                                                                subTextStyle()),
                                                      ],
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Text(
                                                        '${int.parse(standardNumber.toString()) * 2} unit(s)',
                                                        style: subTextStyle()),
                                                  ),
                                                ]),
                                          ),
                                          Divider(),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text('BASIC',
                                                            style:
                                                                buildTextStyle()),
                                                        SizedBox(height: 8),
                                                        Text(
                                                            '$basicNumber Person(s)',
                                                            style:
                                                                subTextStyle()),
                                                      ],
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Text(
                                                        '${int.parse(basicNumber.toString()) * 1} unit(s)',
                                                        style: subTextStyle()),
                                                  ),
                                                ]),
                                          ),
                                          Divider(),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                            'Total number of vetting',
                                                            style:
                                                                buildTextStyle()),
                                                        SizedBox(height: 8),
                                                        Text(
                                                            '$totalNumber Person(s)',
                                                            style:
                                                                subTextStyle()),
                                                      ],
                                                    ),
                                                  ),
                                                ]),
                                          ),
                                          Divider(),
                                          SizedBox(height: 50),
                                          Buttons.authButton(
                                              context: context,
                                              onTap: () {
                                                if (pendingVet != [] ||
                                                    refCodes != [] ||
                                                    pendingVet.length != 0) {
                                                  if (balance < totalUnit)
                                                    Dialogs.showErrorSnackBar(
                                                        'Sorry!',
                                                        'You do not have enough unit in your wallet');
                                                  else
                                                    pay();
                                                } else {
                                                  Dialogs.showErrorSnackBar(
                                                      'Sorry!',
                                                      'YOu cannot submit and empty vet');
                                                }
                                              },
                                              title: 'Make Payment')
                                        ]),
                                      )),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
              color: Theme.of(context).primaryColor,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Center(
                  child: Image.asset(
                    'assets/images/seclot_logo.png',
                    width: 90,
                  ),
                ),
              )),
        ],
      ),
    );
  }

  TextStyle buildTextStyle() => TextStyle(
      color: Colors.black54, fontWeight: FontWeight.w600, fontSize: 18);

  TextStyle subTextStyle() =>
      TextStyle(fontWeight: FontWeight.w600, fontSize: 15);

  unpaidVetCard(
      {context, title, subtitle, address, phoneNumber, status, email}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: Colors.white,
            boxShadow: <BoxShadow>[
              BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  offset: Offset(0.1, 0.3),
                  spreadRadius: 2)
            ]),
        child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 5, 18, 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                        flex: 3,
                        child: Text(
                          '$subtitle',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w600),
                        )),
                    SizedBox(width: 5),
                    Expanded(
                        flex: 2,
                        child: Text(
                          '$title',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w500),
                        )),
                  ],
                ),
                SizedBox(height: 6),
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('$phoneNumber'),
                          SizedBox(height: 2),
                          Text(
                            '$email',
                            style: TextStyle(fontSize: 12),
                          ),
                          SizedBox(height: 2),
                          Text(
                            '$address',
                            style: TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                        flex: 2,
                        child:
                            Text('Status: ${status.toString().toUpperCase()}'))
                  ],
                ),
                SizedBox(height: 10),
              ],
            )),
      ),
    );
  }

  pay() async {
    if (await InternetUtils.checkConnectivity()) {
      print(refCodes);
      Dialogs.showLoading(context: context, text: 'Submitting..');
      var response =
          await VetServices.payFOrVet(token: token, refCodes: refCodes);
      print('response');
      print(response);
      if (response['shortDescription'] != 'SUCCESS') {
        Get.back();
        Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
      } else if (response['shortDescription'] == 'SUCCESS') {
        Get.back();
        Dialogs.showSuccessDialog(
            context: context,
            message: 'You vetting has been successfully submitted',
            actionText: 'Ok',
            action: () {
              Get.offAll(
                () => HomeScreen(),
              );
            });
      } else {
        Dialogs.showErrorSnackBar('Error!', 'Failed to submit, try again');
      }
    } else
      Dialogs.showErrorSnackBar('No Internet', 'Check yur connectivity');
  }
}
