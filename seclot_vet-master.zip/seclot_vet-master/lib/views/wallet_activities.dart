import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/models/user_model.dart';
import 'package:seclot_vet/services/wallet_services.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

class WalletActivities extends StatefulWidget {
  const WalletActivities({Key? key}) : super(key: key);

  @override
  _WalletActivitiesState createState() => _WalletActivitiesState();
}

class _WalletActivitiesState extends State<WalletActivities> {
  String token = '';
  String email = '';
  String userId = '';
  UserController userController = Get.find();
  var initActivities;
  var activities;

  @override
  void initState() {
    token = userController.getToken();
    User user = userController.getUser();
    email = user.email;
    userId = user.userId;

    boot();
    super.initState();
  }

  boot() async {
    var response =
        await WalletServices.getUserWalletTransactions(token, userId);
    print(response);
    if (response['shortDescription'] != 'SUCCESS') {
      Dialogs.showErrorSnackBar('Error Fetching', response);
    } else {
      setState(() {
        activities = response['object']['items'];
        print('activities');
        print(activities.length);
      });
    }
  }

  search(value) {
    if (value.length > 3) {
      print(value);
      print(activities);
      setState(() {
        var list = activities
            .where((element) =>
                (element['activities']
                        .toString()
                        .toLowerCase()
                        .removeAllWhitespace
                        .contains(value) ||
                    element['location']
                        .toString()
                        .toLowerCase()
                        .removeAllWhitespace
                        .contains(value) ||
                    element['phone_number']
                        .toString()
                        .removeAllWhitespace
                        .contains(value) ||
                    element['agent_id']
                        .toString()
                        .removeAllWhitespace
                        .contains(value)) &&
                element != null)
            .toList();
        activities = list;
        print('list');
        print(list);
        print(activities);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Column(
        children: [
          // SizedBox(height: 50),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                ),
                Text(
                  'Wallet Activities',
                  style: TextStyle(
                      letterSpacing: 0.4,
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15),
                ),
                SizedBox(width: 30),
              ],
            ),
          ),

          SizedBox(height: 25),
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(30))),
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 5, 5, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: activities == null
                          ? Center(
                              child: CircularProgressIndicator(
                              color: Theme.of(context).primaryColor,
                            ))
                          : ListView.builder(
                              padding: EdgeInsets.fromLTRB(18, 8, 18, 0),
                              itemCount: activities.length,
                              itemBuilder: (context, index) {
                                var item = activities[index];
                                return walletActivities(
                                    color: item['isApproved']
                                        ? Colors.green
                                        : Colors.orange,
                                    status: item['isApproved']
                                        ? 'Approved'
                                        : 'Pending',
                                    code: item['transCode'],
                                    name: item['transactedBy'],
                                    date: DateFormat.yMMMEd().format(
                                        DateTime.parse(
                                            item['creationTime'].toString())),
                                    amount: item['transactionAmount'],
                                    desc: item['transDescription']);
                              }),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container walletActivities({name, code, status, amount, date, color, desc}) {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 5, 5, 5),
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
          border: Border(left: BorderSide(color: Colors.green, width: 5))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Text('$code',
                    style:
                        TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
              ),
              Expanded(
                  flex: 1,
                  child: Text('$amount Units',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          color: Colors.black54,
                          fontSize: 16,
                          fontWeight: FontWeight.w600))),
            ],
          ),
          SizedBox(height: 4),
          Row(
            children: [
              Expanded(child: Text('$date', style: TextStyle(fontSize: 13))),
              Expanded(
                child: Text('$status',
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 13, color: color)),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text('$desc', style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
