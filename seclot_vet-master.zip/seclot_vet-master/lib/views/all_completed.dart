import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/services/web_services.dart';
import 'package:seclot_vet/views/input_fields.dart';
import 'package:seclot_vet/views/queue_detail.dart';
import 'package:seclot_vet/views/web.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';
import 'package:url_launcher/url_launcher.dart';

import 'all_submitted_vets.dart';

class AllConcludedVets extends StatefulWidget {
  const AllConcludedVets({Key? key}) : super(key: key);

  @override
  _AllConcludedVetsState createState() => _AllConcludedVetsState();
}

class _AllConcludedVetsState extends State<AllConcludedVets> {
  UserController userController = Get.find();
  String token = '';
  String clientId = '';
  var completedVet;
  var allVet;
  var searchVet;
  final searchController = TextEditingController();
  bool isSearch = false;

  @override
  void initState() {
    token = userController.getToken();
    clientId = userController.getUser().userId;
    print(userController.getLogo());
    boot();
    super.initState();
  }

  boot() async {
    getVets();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  getVets() async {
    var response = await WebServices.getVets(token, clientId);
    if (response['shortDescription'] != 'SUCCESS') {
      Dialogs.showErrorSnackBar('Error Fetching', response);
    } else {
      setState(() {
        allVet = response['object']['items'];

        completedVet = allVet
            .where((i) => i['vetteeStatus'] == 4 && i['vetteeStatus'] != null)
            .toList();

        print('completedVet.length');
        print(completedVet.length);
      });
    }
  }

  search(value) {
    if (value.length > 3) {
      print(value);
      setState(() {
        isSearch = true;
        var list = allVet
            .where((element) =>
                (element['referenceCode']
                        .toString()
                        .toLowerCase()
                        .removeAllWhitespace
                        .contains(value
                            .toString()
                            .toLowerCase()
                            .removeAllWhitespace) ||
                    '${element['vetteeFirstName']} ${element['vetteeLastName']}'
                        .toString()
                        .toLowerCase()
                        .removeAllWhitespace
                        .contains(value
                            .toString()
                            .toLowerCase()
                            .removeAllWhitespace)) &&
                element != null)
            .toList();
        searchVet = list;
        print('list');
        print(searchVet);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                ),
                Text(
                  'Concluded Vets',
                  style: GoogleFonts.roboto(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: Colors.white),
                ),
                SizedBox(width: 30),
              ],
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                children: [
                  SizedBox(height: 10),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(30))),
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15),
                        child: Column(
                          children: [
                            Padding(
                              padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                              child: searchBox(
                                  context: context,
                                  labelText: 'Search by Ref or name',
                                  onChanged: (value) => search(value),
                                  searchController: searchController,
                                  close: () {
                                    setState(() {
                                      isSearch = false;
                                      searchController.text = '';
                                    });
                                  }),
                            ),
                            Expanded(
                              child: completedVet == null
                                  ? Column(
                                      children: [
                                        SizedBox(height: 150),
                                        Center(
                                            child: CircularProgressIndicator(
                                          color: Theme.of(context).primaryColor,
                                        )),
                                      ],
                                    )
                                  : completedVet.length == 0
                                      ? Column(
                                          children: [
                                            SizedBox(height: 150),
                                            Center(
                                                child: Text(
                                                    'You do not have any\ncompleted vets',
                                                    textAlign:
                                                        TextAlign.center)),
                                          ],
                                        )
                                      : ListView.builder(
                                          padding: EdgeInsets.all(0),
                                          itemCount: completedVet.length,
                                          itemBuilder: (context, index) {
                                            var item = completedVet[index];
                                            print(item);
                                            return completeVet(
                                              context: context,
                                              title:
                                                  '${item['vetteeFirstName']} ${item['vetteeLastName']}',
                                              subtitle: item['referenceCode'],
                                              picture: item['picture'],
                                              remark: item['vettersRemarks'],
                                              vetImage: item['vetPhotoUpload'],
                                              vetGeolink: item['vetGeoLink'],
                                              vetVideo:
                                                  item['vetVideoUpload'] ??
                                                      'N/A',
                                              email: item['email'] == ''
                                                  ? 'N/A'
                                                  : item['email'],
                                              phoneNumber: item['phoneNumber'],
                                              address: item['address'] ?? 'N/A',
                                            );
                                          }),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  completeVet(
      {context,
      title,
      subtitle,
      vetImage,
      picture,
      vetGeolink,
      remark,
      vetVideo,
      phoneNumber,
      address,
      email}) {
    return Container(
      margin: EdgeInsets.only(bottom: 5),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            collapsedTextColor: Colors.black,
            textColor: Colors.black,
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            key: PageStorageKey<String>(title),
            title: Row(
              children: [
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      fit: BoxFit.fitHeight,
                      image: NetworkImage((picture == null ||
                              picture == '' ||
                              picture == 'null')
                          ? userController.getLogo()
                          : picture),
                      // image: NetworkImage(userController.getLogo())),
                    ),
                  ),
                ),
                SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                      ),
                      Text(subtitle)
                    ],
                  ),
                ),
              ],
            ),
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(left: 35.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 5),
                    Row(children: [
                      Expanded(
                        child: detailWidget('Phone Number', '$phoneNumber'),
                      ),
                      Expanded(
                        child: detailWidget('Email', '$email'),
                      )
                    ]),
                    SizedBox(height: 5),
                    Row(children: [
                      Expanded(
                        child: detailWidget('Address', '$address'),
                      ),
                      Expanded(
                        child: detailWidget('Remark', '$remark'),
                      ),
                    ]),
                    SizedBox(height: 5),
                    InkWell(
                      onTap: () {
                        print('link - $vetGeolink');
                        if (vetGeolink != null && vetGeolink != 'null')
                          // Get.to(() => OpenWebView(
                          //       url: 'https://$vetGeolink',
                          //     ));
                          _launchURL((vetGeolink.toString().contains('http') ||
                                  vetGeolink.toString().contains('https'))
                              ? '$vetGeolink'
                              : 'https://$vetGeolink');
                        else
                          Dialogs.showNoticeSnackBar(
                              'Oops!', 'There is no link in this vet');
                      },
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.grey, width: 0.5)),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                          child: Row(children: [
                            Expanded(
                              child: detailWidget(
                                  'Geolink', 'Click to view on map'),
                            ),
                            Container(
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: Colors.grey, width: 0.5)),
                                child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: Icon(Icons.arrow_right_alt,
                                      color: Colors.grey, size: 12),
                                ))
                          ]),
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    InkWell(
                      onTap: () {
                        print(vetImage);
                        if (vetImage != null && vetImage != 'null')
                          showImage(context: context, image: vetImage);
                        else
                          Dialogs.showNoticeSnackBar(
                              'Oops!', 'There is no image in this vet');
                      },
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.grey, width: 0.5)),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                          child: Row(children: [
                            Expanded(
                              child:
                                  detailWidget('Image', 'Click to view Image'),
                            ),
                            Container(
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: Colors.grey, width: 0.5)),
                                child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: Icon(Icons.arrow_right_alt,
                                      color: Colors.grey, size: 12),
                                ))
                          ]),
                        ),
                      ),
                    ),
                    SizedBox(height: 7),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _launchURL(_url) async => await canLaunch(_url)
      ? await launch(_url)
      : throw 'Could not launch $_url';

  static Future<void> showImage({context, image}) async {
    return showDialog(
        barrierDismissible: true,
        context: context,
        builder: (context) {
          return AlertDialog(
            elevation: 0,
            contentPadding: EdgeInsets.all(0),
            backgroundColor: Colors.transparent,
            content: Stack(
              children: [
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  child: Wrap(
                    children: <Widget>[
                      Column(
                        children: [
                          Container(
                            width: double.infinity,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.network(image))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                InkWell(
                    onTap: () {
                      Get.back();
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white, shape: BoxShape.circle),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Icon(
                              Icons.close,
                              size: 15,
                              color: Colors.black,
                            ),
                          )),
                    ))
              ],
            ),
          );
        });
  }
}
