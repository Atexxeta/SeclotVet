import 'package:flutter/material.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/controllers/bundle_controller.dart';
import 'package:seclot_vet/controllers/package_controller.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/controllers/wallet_controller.dart';
import 'package:seclot_vet/models/bundle_model.dart';
import 'package:seclot_vet/models/user_model.dart';
import 'package:seclot_vet/services/paystack_services.dart';
import 'package:seclot_vet/services/wallet_services.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';
import 'package:seclot_vet/widgets/logo.dart';

import 'card_screen.dart';
import 'input_fields.dart';

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({Key? key}) : super(key: key);

  @override
  _SubscriptionScreenState createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  bool _showPassword = false;

  bool isLoading = false;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController amountController = TextEditingController();
  String userType = 'Individual';
  String token = '';
  String email = '';
  String bundleType = '';
  UserController userController = Get.find();
  WalletController walletController = Get.put(WalletController());
  BundleController bundleController = Get.put(BundleController());

  bool isGeneratingCode = false;
  String paystackRef = '';
  String paystackAccesToken = '';
  final plugin = PaystackPlugin();

  @override
  void initState() {
    plugin.initialize(publicKey: PaystackConst.publicKeyTest);
    token = userController.getToken();
    User user = userController.getUser();
    email = user.email;

    boot();
    super.initState();
  }

  List<BundleModel> bundles = [];

  boot() async {
    var b = await bundleController.getBundles(token);

    setState(() {
      bundles = b;
    });

    print('bundle');
    print(bundles.length);
  }

  chargeCard(amount) async {
    int totalAmount =
        int.parse(double.parse(amount.toString()).toStringAsFixed(0)) * 100;
    setState(() {
      isGeneratingCode = !isGeneratingCode;
    });
    Dialogs.showLoading(context: context);

    Map<dynamic, dynamic> accessCode =
        await PaymentServices.createPayStackAccessCode(email, amount);

    print('accessCode');
    print(accessCode);
    print(accessCode["data"]["access_code"]);
    setState(() {
      Get.back();
      isGeneratingCode = !isGeneratingCode;
    });

    Charge charge = Charge()
      ..amount = totalAmount
      ..accessCode = accessCode["data"]["access_code"]
      ..email = email;

    print('charge');
    print(charge);

    CheckoutResponse response = await plugin.checkout(
      context,
      method:
          CheckoutMethod.selectable, // Defaults to CheckoutMethod.selectable
      charge: charge,
      logo: Image.asset(
        'assets/images/seclot_logo.png',
        color: Colors.black,
        height: 35,
      ),
      fullscreen: true,
    );

    print('final response');
    print(response);
    if (response.status == true) {
      Dialogs.showSuccessDialog(
          context: context,
          message: 'Payment was successfully',
          actionText: 'Great',
          action: () {
            Get.back();
            setState(() {
              paystackRef = response.reference!;
            });
            addMoney(amount);
            print(paystackRef);
          });
    } else {
      if (response.message == 'Access Code does not match public key') {
        Dialogs.showErrorSnackBar(
          'Failed',
          ' Please try again later.',
        );
      } else {
        Dialogs.showErrorSnackBar(
          'Error',
          response.message,
        );
      }
    }
  }

  addMoney(amount) async {
    Dialogs.showLoading(context: context);
    var response = await WalletServices.fundWallet(token,
        email: email, amount: amount, ref: paystackRef, bundleType: bundleType);
    print(response);
    if (response is String) {
      Get.back();
    }
    Get.back();
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.black,
                      size: 25,
                    ),
                  ),
                ),
                Text(
                  'Bundles',
                  style: TextStyle(
                      letterSpacing: 0.4,
                      fontWeight: FontWeight.w700,
                      fontSize: 15),
                ),
                SizedBox(width: 45),
              ],
            ),
          ),
          SizedBox(height: 25),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(30))),
              padding: EdgeInsets.only(top: 80),
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      // height: 500,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(30))),
                      padding:
                          EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(height: 25),
                          Flexible(
                              child: bundles.isEmpty
                                  ? Center(
                                      child: CircularProgressIndicator(
                                          color: Theme.of(context).primaryColor,
                                          backgroundColor: Colors.black12))
                                  : GridView.builder(
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 2,
                                        childAspectRatio: 0.75,
                                        mainAxisSpacing: 10.0,
                                        crossAxisSpacing: 4.0,
                                      ),
                                      itemBuilder: (context, index) {
                                        BundleModel item = bundles[index];
                                        return subscriptionCard(context,
                                            buy: () {
                                          bundleType = item.id;
                                          showAmountDialog(context,
                                              error:
                                                  'Amount must be a multiple of ${item.adsPrice}',
                                              action: () {
                                            var amount = '0';
                                            amount = amountController.text;
                                            print(amount);
                                            print(item.adsPrice);
                                            if (double.parse(amount) <
                                                double.parse(item.adsPrice)) {
                                              Dialogs.showErrorSnackBar(
                                                  'Error!',
                                                  'Enter a valid amount greater or equal to the package amount');
                                            } else {
                                              Get.back();
                                              setState(() {
                                                amountController.text = '';
                                              });
                                              chargeCard(amount);
                                            }
                                          },
                                              message:
                                                  'Enter the Amount of you Unit you want to buy',
                                              amountController:
                                                  amountController);
                                        },
                                            unitCounts: item.unitCounts,
                                            description:
                                                'Buy ${item.code}\nPrice - ${item.adsPrice}\nNumber of unit - ${item.unitCounts}\nRate - ${item.amount} per unit\n${item.description}',
                                            title: item.code,
                                            amount: item.adsPrice);
                                      },
                                      itemCount: bundles.length,
                                    )),
                        ],
                      ),
                    ),
                  ),
                  logo(),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  subscriptionCard(context, {description, title, buy, amount, unitCounts}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: () {},
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: Colors.white,
            boxShadow: <BoxShadow>[
              BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  offset: Offset(0.4, 0.6),
                  blurRadius: 2.0,
                  spreadRadius: 2.0),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 15),
            child: Wrap(
              alignment: WrapAlignment.center,
              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/images/Regular Membership_Badge1 1.png',
                          height: 23,
                          width: 23,
                        ),
                        SizedBox(width: 10),
                        Text(
                          title,
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(height: 20),
                Center(
                  child: Text(
                    '$unitCounts Units',
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(height: 5),
                Center(
                  child: Text(
                    'Cost $amount',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w400),
                  ),
                ),
                Padding(
                    padding: EdgeInsets.fromLTRB(25, 15, 25, 15),
                    child: Buttons.smallButton(
                        context: context, action: buy, actionText: 'Buy now')),
                Center(
                  child: InkWell(
                    onTap: () {
                      showInfoDialog(
                        context: context,
                        message: '$description',
                      );
                    },
                    child: Text(
                      'View more Details',
                      style: TextStyle(
                          fontSize: 12, decoration: TextDecoration.underline),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> showAmountDialog(context,
      {message, action, amountController, error}) async {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return AlertDialog(
            elevation: 0,
            contentPadding: EdgeInsets.all(0),
            backgroundColor: Colors.transparent,
            content: Stack(
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 30),
                  child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    child: Wrap(
                      // mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment:CrossAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 15),
                          decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.2),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 3,
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Text(
                                    message,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 15, 15, 20),
                          child: Column(
                            children: [
                              Container(
                                width: double.infinity,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 15.0,
                                          right: 15.0,
                                          bottom: 15.0,
                                          top: 20),
                                      child: InputFormField(
                                        controller: amountController,
                                        label:'Amount in units',
                                        suffixIcon: Padding(
                                          padding: const EdgeInsets.all(14.0),
                                          child: Text('units'),
                                        ),
                                      ),
                                    ),
                                    Text(error),
                                    Padding(
                                        padding:
                                            EdgeInsets.fromLTRB(25, 15, 25, 15),
                                        child: Buttons.smallButton(
                                            context: context,
                                            action: action,
                                            actionText: 'Buy now')),
                                    SizedBox(
                                      height: 10,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                    top: 5,
                    right: 20,
                    child: InkWell(
                        onTap: () {
                          Get.back();
                        },
                        child: Text(
                          'Close',
                          style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.w600),
                        ))),
              ],
            ),
          );
        });
  }
}

Future<void> showInfoDialog({context, message, actionText}) async {
  return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return AlertDialog(
          elevation: 0,
          contentPadding: EdgeInsets.all(0),
          backgroundColor: Colors.transparent,
          content: Stack(
            children: [
              Padding(
                padding: EdgeInsets.only(top: 30),
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  child: Wrap(
                    // mainAxisAlignment: MainAxisAlignment.center,
                    // crossAxisAlignment:CrossAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 15),
                        decoration: BoxDecoration(
                          color: Colors.grey.withOpacity(0.2),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: Align(
                                alignment: Alignment.centerRight,
                                child: Image.asset(
                                  'assets/images/Regular Membership_Badge1 1.png',
                                  height: 23,
                                  width: 23,
                                ),
                              ),
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              flex: 3,
                              child: Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Text(
                                  'NOTE',
                                  style: TextStyle(
                                      fontSize: 20.0,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 15, 15, 20),
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15.0,
                                        right: 15.0,
                                        bottom: 15.0,
                                        top: 20),
                                    child: Text(
                                      message,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontSize: 14.0,
                                          color: Colors.grey[600]),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                  top: 5,
                  right: 20,
                  child: InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Text(
                        actionText ?? 'Close',
                        style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                            fontWeight: FontWeight.w600),
                      ))),
            ],
          ),
        );
      });
}
