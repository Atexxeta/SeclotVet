import 'package:flutter/material.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
import 'package:get/get.dart';
import 'package:seclot_vet/controllers/package_controller.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/controllers/vet_controller.dart';
import 'package:seclot_vet/controllers/wallet_controller.dart';
import 'package:seclot_vet/models/user_model.dart';
import 'package:seclot_vet/services/paystack_services.dart';
import 'package:seclot_vet/views/drawer.dart';
import 'package:seclot_vet/views/profile.dart';
import 'package:seclot_vet/views/all_completed.dart';
import 'package:seclot_vet/views/subscription_screen.dart';
import 'package:seclot_vet/views/uncompleted_vets.dart';
import 'package:seclot_vet/views/wallet_activities.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import 'all_submitted_vets.dart';
import 'vetting_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String token = '';
  String email = '';
  String name = '';
  String id = '';
  double balance = 0.0;
  String walletId = '';
  String amount = '';
  String identificationCode = '';
  String nxtofKin = '';
  String dob = '';
  String address = '';
  String profilePic = '';
  TextEditingController amountController = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  UserController userController = Get.find();
  VetController vetController = Get.put(VetController());
  WalletController walletController = Get.put(WalletController());
  PackageController packageController = Get.put(PackageController());
  final plugin = PaystackPlugin();

  @override
  void initState() {
    plugin.initialize(publicKey: PaystackConst.publicKeyTest);

    boot();
    super.initState();
  }

  boot() async {
    token = userController.getToken();
    User user = userController.getUser();
    String fName = user.firstName;
    String lName = user.lastName;
    setState(() {
      name = '$fName $lName';
      print(name);

      email = user.email;
      id = user.userId;
      walletId = user.walletId.toString();
      address = user.address.toString();
      dob = user.dateOfBirth.toString();
      nxtofKin = user.nextOfKin.toString();
      identificationCode = user.identificationCode.toString();

      profilePic = (user.photo == 'null' || user.photo == '')
          ? userController.getLogo()
          : user.photo;
      print('profilePic');
      print(profilePic.length);
    });
    await vetController.getAllTerminals(token);
    await packageController.getAllPackages(token);
    var walletDetail = await walletController.getWallet(token, walletId);
    setState(() {
      balance = walletDetail['balance'] ?? 0.0;
    });
  }

  //info@seclot.com
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Theme.of(context).primaryColor,
      drawer: Drawer(
        child: SideDrawer(),
      ),
      body: Stack(
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () {
                        _scaffoldKey.currentState!.openDrawer();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.list,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),
                    ),
                    SizedBox(width: 30),
                  ],
                ),
              ),
              Image.asset(
                'assets/images/seclot_logo.png',
                width: MediaQuery.of(context).size.width * 0.28,
              ),
              SizedBox(height: 25),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(30))),
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        SizedBox(height: 25),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 85,
                              width: 85,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    fit: BoxFit.fitHeight,
                                    image: NetworkImage(profilePic)),
                              ),
                            ),
                            SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          Get.to(() => ProfileScreen())!
                                              .then((value) => boot());
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Theme.of(context)
                                                  .primaryColor),
                                          child: Padding(
                                            padding: const EdgeInsets.all(6.0),
                                            child: Icon(
                                              Icons.edit,
                                              color: Colors.white,
                                              size: 20,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Text('Hello'),
                                  InkWell(
                                    onTap: () async {
                                      Get.to(() => ProfileScreen())!
                                          .then((value) => boot());
                                    },
                                    child: Text(
                                      '$name',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 16),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(width: 12),
                          ],
                        ),
                        SizedBox(height: 25),
                        Stack(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 0.5,
                                  color: Colors.grey.withOpacity(0.6),
                                ),
                              ),
                              height: 110,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0, 15, 0, 15),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            '$balance units',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                                fontSize: 26),
                                          ),
                                          Text(
                                            'Wallet Balance',
                                            style: TextStyle(fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                      color: Colors.grey.withOpacity(0.6),
                                      width: 1,
                                      height: 100),
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0, 15, 0, 15),
                                      child: InkWell(
                                        onTap: () {
                                          if (identificationCode == 'null' ||
                                              address == 'null' ||
                                              dob == 'null')
                                            Dialogs.showNoticeSnackBar('Sorry!',
                                                'You have to update your profile to be able to create a vet');
                                          else
                                            Get.to(() => SubscriptionScreen());
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              'Top up',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 26),
                                            ),
                                            Text(
                                              'Buy packages',
                                              style: TextStyle(fontSize: 12),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 30),
                        Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                onTap: () {
                                  if (identificationCode == 'null' ||
                                      address == 'null' ||
                                      dob == 'null')
                                    Dialogs.showNoticeSnackBar('Sorry!',
                                        'You have to update your profile to be able to create a vet');
                                  else
                                    Get.to(() => VettingScreen())!
                                        .then((value) => boot());
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.white,
                                    boxShadow: <BoxShadow>[
                                      BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          offset: Offset(0.3, 0.4))
                                    ],
                                    border: Border.all(
                                      width: 0.5,
                                      color: Colors.grey.withOpacity(0.6),
                                    ),
                                  ),
                                  height: 170,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.grey.withOpacity(0.2),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(17.0),
                                          child: Image.asset(
                                            'assets/icons/vet.png',
                                            height: 35,
                                            width: 35,
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text(
                                        'Create Vet',
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 35),
                            Expanded(
                              child: InkWell(
                                onTap: () {
                                  Get.to(() => AllConcludedVets())!
                                      .then((value) => boot());
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    boxShadow: <BoxShadow>[
                                      BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          offset: Offset(0.3, 0.4))
                                    ],
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      width: 0.5,
                                      color: Colors.grey.withOpacity(0.6),
                                    ),
                                  ),
                                  height: 170,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.grey.withOpacity(0.2),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(17.0),
                                          child: Image.asset(
                                            'assets/icons/Door Sensor Checked.png',
                                            height: 35,
                                            width: 35,
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text(
                                        'Completed Vet',
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20),
                        Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                onTap: () {
                                  Get.to(() => CompletedVetScreen());
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.white,
                                    boxShadow: <BoxShadow>[
                                      BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          offset: Offset(0.3, 0.4))
                                    ],
                                    border: Border.all(
                                      width: 0.5,
                                      color: Colors.grey.withOpacity(0.6),
                                    ),
                                  ),
                                  height: 170,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.grey.withOpacity(0.2),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(17.0),
                                          child: Image.asset(
                                            'assets/icons/queue.png',
                                            height: 35,
                                            width: 35,
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text(
                                        'Vet History',
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 35),
                            Expanded(
                              child: InkWell(
                                onTap: () {
                                  Get.to(() => WalletActivities());
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    boxShadow: <BoxShadow>[
                                      BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          offset: Offset(0.3, 0.4))
                                    ],
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      width: 0.5,
                                      color: Colors.grey.withOpacity(0.6),
                                    ),
                                  ),
                                  height: 170,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.grey.withOpacity(0.2),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(17.0),
                                          child: Image.asset(
                                            'assets/icons/Data Pending.png',
                                            height: 35,
                                            width: 35,
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text(
                                        'Activities',
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
          if (identificationCode == 'null' ||
              address == 'null' ||
              dob == 'null')
            Padding(
              padding: const EdgeInsets.fromLTRB(50, 38, 20, 0),
              child: InkWell(
                onTap: () {
                  Get.to(() => ProfileScreen())!.then((value) => boot());
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15)),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Hey $name\nYou need to update your profile information to be able to use this account.\nClick to update now.',
                            style:
                                TextStyle(fontSize: 12, color: Colors.orange),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            )
        ],
      ),
    );
  }
}
