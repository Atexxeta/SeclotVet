import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import 'homepage.dart';

class VettingSummaryScreen extends StatefulWidget {
  const VettingSummaryScreen({Key? key}) : super(key: key);

  @override
  _VettingSummaryScreenState createState() => _VettingSummaryScreenState();
}

class _VettingSummaryScreenState extends State<VettingSummaryScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Column(
        children: [
          // SizedBox(height: 50),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                ),
                Text(''),
                SizedBox(width: 30),
              ],
            ),
          ),

          SizedBox(height: 25),
          Expanded(
            child: Container(
              // height: MediaQuery.of(context).size.height * 0.8,
              decoration: BoxDecoration(
                color: Theme.of(context).accentColor,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 20, 0, 25),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            'Vetting Analysis',
                            style: GoogleFonts.roboto(
                                fontSize: 18, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(30))),
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 10),
                              Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(15, 20, 5, 20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    detailWidget('No. of person(s)', '5'),
                                    detailWidget('Price/person', '\u20A61500'),
                                    SizedBox(height: 10),
                                    detailWidget('Total', '\u20A67500'),
                                    SizedBox(height: 10),
                                    detailWidget('Discount Applied', 'None'),
                                    SizedBox(height: 10),
                                    detailWidget('Summed Total', '\u20A67500'),
                                    SizedBox(height: 40),
                                    Buttons.authButton(
                                        context: context,
                                        onTap: () {
                                          Dialogs.vetSuccess(
                                            context: context,
                                            actionText: 'Got back home',
                                            title:
                                                'File(s) Successfully Uploaded',
                                            message:
                                                'Will be reviewed before:\nJuly 15th',
                                            date:
                                                'Date of Submission: July 12, 2021',
                                            action: () {
                                              Get.offAll(() => HomeScreen());
                                            },
                                          );
                                        },
                                        title: 'Vet'),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  detailWidget(title, desc) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(5),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  '$title : ',
                  style: TextStyle(color: Colors.black54, fontSize: 16),
                ),
              ),
              SizedBox(width: 15),
              Expanded(
                child: Text(
                  desc,
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 4),
        Divider(
          thickness: 0.5,
          color: Colors.grey.withOpacity(0.8),
        ),
      ],
    );
  }
}
