import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/routes.dart';
import 'package:seclot_vet/services/auth_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/views/otp.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'input_fields.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  bool _showPassword = false;

  bool isLoading = false;
  bool privacy = false;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String userType = 'Individual';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // SizedBox(height: 50),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.west,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                    ),
                    Text(''),
                    SizedBox(width: 30),
                  ],
                ),
              ),
              Image.asset(
                'assets/images/seclot_logo.png',
                width: MediaQuery.of(context).size.width * 0.28,
              ),
              SizedBox(height: 25),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                      color: Theme.of(context).accentColor,
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(30))),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 20, 0, 25),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Create Account',
                                style: GoogleFonts.roboto(color:Colors.white,
                                    fontSize: 18, fontWeight: FontWeight.w700),
                              ),
                            ),
                            Text(
                              'What kind of account would you like to create?',
                              style: GoogleFonts.roboto(color:Colors.white,
                                  fontSize: 14, fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(30))),
                          padding: EdgeInsets.symmetric(
                              horizontal: 15, vertical: 20),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                SizedBox(height: 10),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.person_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: firstNameController,
                                        obscure: false,
                                        label: 'First name',
                                        textCapitalization:
                                            TextCapitalization.words,
                                        keyboardType:
                                            TextInputType.text,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter a valid name";
                                          }
                                          return null;
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.person_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: lastNameController,
                                        obscure: false,
                                        label: 'Last name',
                                        textCapitalization:
                                            TextCapitalization.words,
                                        keyboardType:
                                            TextInputType.text,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter a valid name";
                                          }
                                          return null;
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.mail_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: emailController,
                                        obscure: false,
                                        label: 'Email',
                                        textCapitalization:
                                            TextCapitalization.none,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                        suffixIcon: emailController.text.isEmpty
                                            ? Text('')
                                            : emailController.text.isNotEmpty &&
                                                    emailController.text
                                                        .contains('@') &&
                                                    emailController.text
                                                        .contains('.')
                                                ? Icon(
                                                    Icons.done,
                                                    color: Colors.greenAccent,
                                                  )
                                                : Icon(
                                                    Icons.close,
                                                    color: Colors.redAccent,
                                                  ),
                                        validator: (value) {
                                          if (value.isEmpty ||
                                              !value.contains('@') ||
                                              !value.contains('.')) {
                                            return "Please enter a valid email";
                                          }
                                          return null;
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.call_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: phoneController,
                                        obscure: false,
                                        label: 'Phone number',
                                        textCapitalization:
                                            TextCapitalization.none,
                                        keyboardType:
                                            TextInputType.phone,
                                        suffixIcon: phoneController.text.isEmpty
                                            ? Text('')
                                            : (phoneController.text
                                                        .startsWith('0') &&
                                                    phoneController
                                                            .text.length ==
                                                        11)
                                                ? Icon(
                                                    Icons.done,
                                                    color: Colors.greenAccent,
                                                  )
                                                : Icon(
                                                    Icons.close,
                                                    color: Colors.redAccent,
                                                  ),
                                        validator: (value) {
                                          if (value.isEmpty ||
                                              !value.startsWith('0') ||
                                              value.length != 11) {
                                            return "Please enter a valid phone number";
                                          }
                                          return null;
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.security_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: passwordController,
                                        obscure: !_showPassword,
                                        validator: (value) {
                                          if (value.isEmpty ||
                                              value.length < 4) {
                                            return "Please enter a valid password";
                                          }
                                          return null;
                                        },
                                        label: 'Password',
                                        textCapitalization:
                                            TextCapitalization.none,
                                        suffixIcon: IconButton(
                                          onPressed: () {
                                            setState(() =>
                                                _showPassword = !_showPassword);
                                          },
                                          icon: !_showPassword
                                              ? Text(
                                                  'Show',
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 11),
                                                )
                                              : Text(
                                                  'Hide',
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 11),
                                                ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.security_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: confirmPasswordController,
                                        obscure: !_showPassword,
                                        validator: (value) {
                                          if (passwordController.text !=
                                              confirmPasswordController.text) {
                                            return "Password do not match";
                                          }
                                          return null;
                                        },
                                        label: 'Confirm Password',
                                        textCapitalization:
                                            TextCapitalization.none,
                                        suffixIcon: IconButton(
                                          onPressed: () {
                                            print(_showPassword);
                                            setState(() =>
                                                _showPassword = !_showPassword);
                                          },
                                          icon: !_showPassword
                                              ? Text(
                                                  'Show',
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 11),
                                                )
                                              : Text(
                                                  'Hide',
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 11),
                                                ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10),
                                Center(
                                  child: Row(
                                    children: [
                                      Theme(
                                        data: ThemeData(
                                          unselectedWidgetColor:
                                              Theme.of(context).primaryColor,
                                        ),
                                        child: Checkbox(
                                          activeColor:
                                              Theme.of(context).primaryColor,
                                          checkColor: Colors.white,
                                          value: privacy,
                                          onChanged: (value) {
                                            setState(() {
                                              privacy = value!;
                                            });
                                          },
                                        ),
                                      ),
                                      Expanded(
                                        child: InkWell(
                                          onTap: () {
                                            _launchURL('https://vet.seclot.com/T&C');
                                          },
                                          child: RichText(
                                            textAlign: TextAlign.center,
                                            text: TextSpan(
                                              children: [
                                                TextSpan(
                                                    text:
                                                        'By clicking “register”, you agree to all statements in',
                                                    style: TextStyle(
                                                      color: Colors.black,
                                                      fontSize: 11,
                                                    )),
                                                TextSpan(
                                                  text:
                                                      '\nTerms and Conditions',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                    color: Colors.black,
                                                    fontSize: 11,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 20),
                                Buttons.authButton(
                                    context: context,
                                    onTap: () {
                                      isLoading?print('==saving'):    createUser();
                                      // Get.to(() => OtpScreen());
                                    },
                                    title:isLoading?'Submitting...': 'Register'),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  userOption({
    context,
    title,
  }) {
    return InkWell(
      onTap: () {
        setState(() {
          userType = title;
        });
      },
      child: Container(
        decoration: BoxDecoration(
          color:
              userType == title ? Colors.white : Theme.of(context).primaryColor,
          borderRadius: BorderRadius.circular(30),
        ),
        padding: EdgeInsets.all(8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Theme.of(context).scaffoldBackgroundColor),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  Icons.person,
                  size: 15,
                ),
              ),
            ),
            SizedBox(width: 13),
            Expanded(
                child: Text(
              title,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: userType == title
                      ? Theme.of(context).primaryColor
                      : Colors.white),
            ))
          ],
        ),
      ),
    );
  }

  void _launchURL(_url) async =>
      await canLaunch(_url) ? await launch(_url) : throw 'Could not launch $_url';

  changeLoadingState() {
    setState(() {
      isLoading = !isLoading;
    });
  }

  createUser() async {
    print(privacy);
    if (privacy == true) {
      if (await InternetUtils.checkConnectivity()) {
        if (_formKey.currentState!.validate()) {
          changeLoadingState();
          var response = await AuthenticationService.register(
            password: passwordController.text,
            confirmPassword: confirmPasswordController.text,
            customerPhone: phoneController.text,
            customerEmail: emailController.text,
            customerFirstName: firstNameController.text,
            customerLastName: lastNameController.text,
          );
          if (response is String) {
            changeLoadingState();
            Dialogs.showErrorSnackBar('Error', response);
          }else if(response['shortDescription']!='SUCCESS'){
            if(response['shortDescription'].length>100)
            Dialogs.showErrorSnackBar('Failed!', 'Please try again later');
            else
            Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
          } else {
            Get.toNamed(
                Routes.activateAccount,
                arguments: {
                  'email': emailController.text,
                  'phone': phoneController.text,
                  'password': passwordController.text,
                });
          }
        } else {
          Dialogs.showErrorSnackBar(
              'Error', 'Ensure all required fields are filled');
        }
      } else {
        Dialogs.showErrorSnackBar(
            'No Internet!', 'Please check your internet connection.');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'Error', 'Ensure you agree with terms and conditions');
    }
    setState(() {
      isLoading = false;
    });
  }
}
