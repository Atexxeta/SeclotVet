import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/controllers/package_controller.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/controllers/vet_controller.dart';
import 'package:seclot_vet/models/package_model.dart';
import 'package:seclot_vet/models/user_model.dart';
import 'package:seclot_vet/models/vet_model.dart';
import 'package:seclot_vet/services/vet_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/views/input_fields.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';
import '../main.dart';
import 'pending_vets.dart';
import 'subscription_screen.dart';
import 'uncompleted_vets.dart';

class VettingScreen extends StatefulWidget {
  const VettingScreen({Key? key}) : super(key: key);

  @override
  _VettingScreenState createState() => _VettingScreenState();
}

class _VettingScreenState extends State<VettingScreen> {
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController phoneNumberController2 = TextEditingController();
  final TextEditingController phoneNumberController3 = TextEditingController();
  final TextEditingController phoneNumberController4 = TextEditingController();
  final TextEditingController phoneNumberController5 = TextEditingController();
  final TextEditingController phoneNumberController6 = TextEditingController();
  final TextEditingController phoneNumberController7 = TextEditingController();
  final TextEditingController phoneNumberController8 = TextEditingController();
  final TextEditingController phoneNumberController9 = TextEditingController();
  final TextEditingController phoneNumberController10 = TextEditingController();
  final TextEditingController fNameController = TextEditingController();
  final TextEditingController fNameController2 = TextEditingController();
  final TextEditingController fNameController3 = TextEditingController();
  final TextEditingController fNameController4 = TextEditingController();
  final TextEditingController fNameController5 = TextEditingController();
  final TextEditingController fNameController6 = TextEditingController();
  final TextEditingController fNameController7 = TextEditingController();
  final TextEditingController fNameController8 = TextEditingController();
  final TextEditingController fNameController9 = TextEditingController();
  final TextEditingController fNameController10 = TextEditingController();
  final TextEditingController lNameController = TextEditingController();
  final TextEditingController lNameController2 = TextEditingController();
  final TextEditingController lNameController3 = TextEditingController();
  final TextEditingController lNameController4 = TextEditingController();
  final TextEditingController lNameController5 = TextEditingController();
  final TextEditingController lNameController6 = TextEditingController();
  final TextEditingController lNameController7 = TextEditingController();
  final TextEditingController lNameController8 = TextEditingController();
  final TextEditingController lNameController9 = TextEditingController();
  final TextEditingController lNameController10 = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController emailController2 = TextEditingController();
  final TextEditingController emailController3 = TextEditingController();
  final TextEditingController emailController4 = TextEditingController();
  final TextEditingController emailController5 = TextEditingController();
  final TextEditingController emailController6 = TextEditingController();
  final TextEditingController emailController7 = TextEditingController();
  final TextEditingController emailController8 = TextEditingController();
  final TextEditingController emailController9 = TextEditingController();
  final TextEditingController emailController10 = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController addressController2 = TextEditingController();
  final TextEditingController addressController3 = TextEditingController();
  final TextEditingController addressController4 = TextEditingController();
  final TextEditingController addressController5 = TextEditingController();
  final TextEditingController addressController6 = TextEditingController();
  final TextEditingController addressController7 = TextEditingController();
  final TextEditingController addressController8 = TextEditingController();
  final TextEditingController addressController9 = TextEditingController();
  final TextEditingController addressController10 = TextEditingController();
  final TextEditingController oNameController = TextEditingController();
  final TextEditingController oNameController2 = TextEditingController();
  final TextEditingController oNameController3 = TextEditingController();
  final TextEditingController oNameController4 = TextEditingController();
  final TextEditingController oNameController5 = TextEditingController();
  final TextEditingController oNameController6 = TextEditingController();
  final TextEditingController oNameController7 = TextEditingController();
  final TextEditingController oNameController8 = TextEditingController();
  final TextEditingController oNameController9 = TextEditingController();
  final TextEditingController oNameController10 = TextEditingController();
  final TextEditingController serviceController = TextEditingController();
  final TextEditingController serviceController2 = TextEditingController();
  final TextEditingController serviceController3 = TextEditingController();
  final TextEditingController serviceController4 = TextEditingController();
  final TextEditingController serviceController5 = TextEditingController();
  final TextEditingController serviceController6 = TextEditingController();
  final TextEditingController serviceController7 = TextEditingController();
  final TextEditingController serviceController8 = TextEditingController();
  final TextEditingController serviceController9 = TextEditingController();
  final TextEditingController serviceController10 = TextEditingController();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController stateController2 = TextEditingController();
  final TextEditingController stateController3 = TextEditingController();
  final TextEditingController stateController5 = TextEditingController();
  final TextEditingController stateController4 = TextEditingController();
  final TextEditingController stateController6 = TextEditingController();
  final TextEditingController stateController7 = TextEditingController();
  final TextEditingController stateController8 = TextEditingController();
  final TextEditingController stateController9 = TextEditingController();
  final TextEditingController stateController10 = TextEditingController();
  final TextEditingController terminalController = TextEditingController();
  final TextEditingController terminalController2 = TextEditingController();
  final TextEditingController terminalController3 = TextEditingController();
  final TextEditingController terminalController5 = TextEditingController();
  final TextEditingController terminalController4 = TextEditingController();
  final TextEditingController terminalController6 = TextEditingController();
  final TextEditingController terminalController7 = TextEditingController();
  final TextEditingController terminalController8 = TextEditingController();
  final TextEditingController terminalController9 = TextEditingController();
  final TextEditingController terminalController10 = TextEditingController();

  PackageController packageController = Get.put(PackageController());
  VetController vetController = Get.put(VetController());
  UserController userController = Get.find();
  final _formKey = GlobalKey<FormState>();
  String token = '';
  String clientId = '';
  String id = '';
  String picture = '';
  String picture2 = '';
  String picture3 = '';
  String picture4 = '';
  String picture5 = '';
  String picture6 = '';
  String picture7 = '';
  String picture8 = '';
  String picture9 = '';
  String picture10 = '';
  String tenantId = '';
  String vetteeListID = '';
  String vetteeListID2 = '';
  String vetteeListID3 = '';
  String vetteeListID4 = '';
  String vetteeListID5 = '';
  String vetteeListID6 = '';
  String vetteeListID7 = '';
  String vetteeListID8 = '';
  String vetteeListID9 = '';
  String vetteeListID10 = '';
  File? _image;
  File? _image2;
  File? _image3;
  File? _image4;
  File? _image5;
  File? _image6;
  File? _image7;
  File? _image8;
  File? _image9;
  File? _image10;
  var vetDetail;
  var terminals = [];
  List<PackageModel> packages = [];

  @override
  void initState() {
    token = userController.getToken();
    boot();

    User user = userController.getUser();
    clientId = user.userId;

    var argument = Get.arguments;
    if (argument != null) {
      vetDetail = argument['vet'];
      print(vetDetail);
      setState(() {
        id = vetDetail['id'].toString();
        vetteeListID = vetDetail['vetteeListID'].toString();
        tenantId = vetDetail['tenantId'].toString();
      });
    }
    super.initState();
  }

  boot() async {
    print('terminals');

    var p = await packageController.getAllPackages(token);
    var t = await vetController.getAllTerminals(token);
    setState(() {
      packages = p;
      terminals = t;
    });
    print(terminals);
  }

  Future _showTerminalOption(BuildContext context) {
    return showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) =>
            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                    bottom: MediaQuery
                        .of(context)
                        .viewInsets
                        .bottom),
                height: MediaQuery
                    .of(context)
                    .size
                    .height * 0.4,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                ),
                child: _buildTerminalMenu(),
              ),
            ));
  }

  _buildTerminalMenu() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
          color: Theme
              .of(context)
              .scaffoldBackgroundColor),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Center(
                child: Text(
                  'Select a Location',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Theme
                          .of(context)
                          .primaryColor),
                ),
              ),
            ),
          ),
          Divider(),
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                child: Column(
                  children: List<Widget>.generate(terminals.length, (index) {
                    var item = terminals[index];
                    return new ListTile(
                      onTap: () => _selectTerminal(item),
                      title: Text(
                        item['name'],
                        softWrap: true,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: vetIIndex == 2
                              ? terminalController2.text == item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 3
                              ? terminalController3.text == item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 4
                              ? terminalController4.text == item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 5
                              ? terminalController5.text ==
                              item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 6
                              ? terminalController6.text ==
                              item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 7
                              ? terminalController7.text ==
                              item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 8
                              ? terminalController8
                              .text ==
                              item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 9
                              ? terminalController9
                              .text ==
                              item['name']
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 10
                              ? terminalController10
                              .text ==
                              item[
                              'name']
                              ? FontWeight
                              .w600
                              : FontWeight
                              .w500
                              : terminalController
                              .text ==
                              item[
                              'name']
                              ? FontWeight
                              .w600
                              : FontWeight
                              .w500,
                        ),
                      ),
                      trailing: vetIIndex == 2
                          ? terminalController2.text == item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 3
                          ? terminalController3.text == item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 4
                          ? terminalController4.text == item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 5
                          ? terminalController5.text == item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 6
                          ? terminalController6.text ==
                          item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 7
                          ? terminalController7.text ==
                          item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 8
                          ? terminalController8.text ==
                          item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 9
                          ? terminalController9.text ==
                          item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 10
                          ? terminalController10
                          .text ==
                          item['name']
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : terminalController
                          .text ==
                          item['name']
                          ? Icon(
                          Icons.circle,
                          size: 15,
                          color: Theme
                              .of(
                              context)
                              .primaryColor)
                          : Text(''),
                    );
                  }),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String vetCity = '';
  String vetCity2 = '';
  String vetCity3 = '';
  String vetCity4 = '';
  String vetCity5 = '';
  String vetCity6 = '';
  String vetCity7 = '';
  String vetCity8 = '';
  String vetCity9 = '';
  String vetCity10 = '';

  void _selectTerminal(item) {
    Get.back();

    setState(() {
      if (vetIIndex == 1) {
        vetCity = item['id'].toString();
        terminalController.text = item['name'];
      }
      if (vetIIndex == 2) {
        vetCity2 = item['id'].toString();

        terminalController2.text = item['name'];
      }
      if (vetIIndex == 3) {
        vetCity3 = item['id'].toString();

        terminalController3.text = item['name'];
      }
      if (vetIIndex == 4) {
        vetCity4 = item['id'].toString();

        terminalController4.text = item['name'];
      }
      if (vetIIndex == 5) {
        vetCity5 = item['id'].toString();

        terminalController5.text = item['name'];
      }
      if (vetIIndex == 6) {
        vetCity6 = item['id'].toString();

        terminalController6.text = item['name'];
      }
      if (vetIIndex == 7) {
        vetCity7 = item['id'].toString();

        terminalController7.text = item['name'];
      }
      if (vetIIndex == 8) {
        vetCity8 = item['id'].toString();

        terminalController8.text = item['name'];
      }
      if (vetIIndex == 9) {
        vetCity9 = item['id'].toString();

        terminalController9.text = item['name'];
      }
      if (vetIIndex == 10) {
        vetCity10 = item['id'].toString();

        terminalController10.text = item['name'];
      }
    });
  }

  Future _showServiceOption(BuildContext context) {
    return showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) =>
            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                    bottom: MediaQuery
                        .of(context)
                        .viewInsets
                        .bottom),
                height: MediaQuery
                    .of(context)
                    .size
                    .height * 0.4,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                ),
                child: _buildServiceMenu(),
              ),
            ));
  }

  _buildServiceMenu() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
          color: Theme
              .of(context)
              .scaffoldBackgroundColor),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Center(
                child: Text(
                  'Select service type',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Theme
                          .of(context)
                          .primaryColor),
                ),
              ),
            ),
          ),
          Divider(),
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                child: Column(
                  children: List<Widget>.generate(packages.length, (index) {
                    var item = packages[index];
                    return new ListTile(
                      onTap: () => _selectServiceOption(item),
                      title: Text(
                        item.description,
                        softWrap: true,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: vetIIndex == 2
                              ? serviceController2.text == item.description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 3
                              ? serviceController3.text == item.description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 4
                              ? serviceController4.text ==
                              item.description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 5
                              ? serviceController5.text ==
                              item.description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 6
                              ? serviceController6.text ==
                              item.description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 7
                              ? serviceController7.text ==
                              item.description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 8
                              ? serviceController8
                              .text ==
                              item.description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 9
                              ? serviceController9
                              .text ==
                              item
                                  .description
                              ? FontWeight.w600
                              : FontWeight.w500
                              : vetIIndex == 10
                              ? serviceController10
                              .text ==
                              item
                                  .description
                              ? FontWeight
                              .w600
                              : FontWeight
                              .w500
                              : serviceController
                              .text ==
                              item
                                  .description
                              ? FontWeight
                              .w600
                              : FontWeight
                              .w500,
                        ),
                      ),
                      trailing: vetIIndex == 2
                          ? serviceController2.text == item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 3
                          ? serviceController3.text == item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 4
                          ? serviceController4.text == item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 5
                          ? serviceController5.text ==
                          item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 6
                          ? serviceController6.text ==
                          item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 7
                          ? serviceController7.text ==
                          item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 8
                          ? serviceController8.text ==
                          item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 9
                          ? serviceController9.text ==
                          item.description
                          ? Icon(Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : vetIIndex == 10
                          ? serviceController10
                          .text ==
                          item
                              .description
                          ? Icon(
                          Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text('')
                          : serviceController
                          .text ==
                          item
                              .description
                          ? Icon(
                          Icons.circle,
                          size: 15,
                          color: Theme
                              .of(context)
                              .primaryColor)
                          : Text(''),
                    );
                  }),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String serviceOption = '';
  String serviceID = '';
  String serviceID2 = '';
  String serviceID3 = '';
  String serviceID4 = '';
  String serviceID5 = '';
  String serviceID6 = '';
  String serviceID7 = '';
  String serviceID8 = '';
  String serviceID9 = '';
  String serviceID10 = '';

  int vetIIndex = 1;

  void _selectServiceOption(packages) {
    Get.back();

    setState(() {
      if (vetIIndex == 1) {
        serviceID = packages.id;
        serviceController.text = packages.description;
      }
      if (vetIIndex == 2) {
        serviceID2 = packages.id;
        serviceController2.text = packages.description;
      }
      if (vetIIndex == 3) {
        serviceID3 = packages.id;
        serviceController3.text = packages.description;
      }
      if (vetIIndex == 4) {
        serviceID4 = packages.id;
        serviceController4.text = packages.description;
      }
      if (vetIIndex == 5) {
        serviceID5 = packages.id;
        serviceController5.text = packages.description;
      }
      if (vetIIndex == 6) {
        serviceID6 = packages.id;
        serviceController6.text = packages.description;
      }
      if (vetIIndex == 7) {
        serviceID7 = packages.id;
        serviceController7.text = packages.description;
      }
      if (vetIIndex == 8) {
        serviceID8 = packages.id;
        serviceController8.text = packages.description;
      }
      if (vetIIndex == 9) {
        serviceID9 = packages.id;
        serviceController9.text = packages.description;
      }
      if (vetIIndex == 10) {
        serviceID10 = packages.id;
        serviceController10.text = packages.description;
      }
    });
    showInfoDialog(
        context: context,
        actionText: 'OK',
        message:
        'You will be charged with ${packages
            .costInUnit} units\nfor this service type and it will take ${packages
            .toVetDaysCount} days.');
  }

  void expandView(bool value) {
    setState(() {
      expanded = value;
    });
  }

  bool expanded = true;
  bool expanded2 = false;
  bool expanded3 = false;
  bool expanded4 = false;
  bool expanded5 = false;
  bool expanded6 = false;
  bool expanded7 = false;
  bool expanded8 = false;
  bool expanded9 = false;
  bool expanded10 = false;
  double h = 650;
  bool removeView = false;
  bool removeViewStored = false;
  List<VetModel> vetItems = [];

  Future _selectImageOption({onTapCamera, onTapGallery}) {
    return showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) =>
            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                    bottom: MediaQuery
                        .of(context)
                        .viewInsets
                        .bottom),
                height: MediaQuery
                    .of(context)
                    .size
                    .height * 0.25,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                ),
                child: Container(
                    decoration: BoxDecoration(
                        borderRadius:
                        BorderRadius.vertical(top: Radius.circular(25)),
                        color: Theme
                            .of(context)
                            .scaffoldBackgroundColor),
                    child: Column(children: [
                      SizedBox(height: 20),
                      InkWell(
                        onTap: onTapCamera,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
                          child: Row(
                            children: [
                              Icon(Icons.camera_alt,
                                  color: Colors.grey, size: 35),
                              SizedBox(width: 25),
                              Expanded(
                                  child: Text('Select Image from Camera',
                                      style: TextStyle(fontSize: 18))),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      InkWell(
                        onTap: onTapGallery,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
                          child: Row(
                            children: [
                              Icon(Icons.photo_album,
                                  color: Colors.grey, size: 35),
                              SizedBox(width: 25),
                              Expanded(
                                  child: Text('Select Image from Gallery',
                                      style: TextStyle(fontSize: 18))),
                            ],
                          ),
                        ),
                      ),
                    ])),
              ),
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme
          .of(context)
          .primaryColor,
      floatingActionButton: FloatingActionButton(
        backgroundColor: Theme
            .of(context)
            .primaryColor,
        onPressed: () {
          if (_formKey.currentState!.validate()) {
            _formKey.currentState!.save();
            if (vetIIndex < 11) {
              setState(() {
                vetIIndex++;
                expanded = false;
                expanded2 = vetIIndex == 2 ? true : false;
                expanded3 = vetIIndex == 3 ? true : false;
                expanded4 = vetIIndex == 4 ? true : false;
                expanded5 = vetIIndex == 5 ? true : false;
                expanded6 = vetIIndex == 6 ? true : false;
                expanded7 = vetIIndex == 7 ? true : false;
                expanded8 = vetIIndex == 8 ? true : false;
                expanded9 = vetIIndex == 9 ? true : false;
                expanded10 = vetIIndex == 10 ? true : false;
              });
            } else
              Dialogs.showErrorSnackBar(
                  'Sorry!', 'You cannot submit more than 5 vets at a time');
          }
          print(vetIIndex);
        },
        child: Icon(
          Icons.add,
          size: 35,
        ),
      ),
      body: Column(
        children: [
          // SizedBox(height: 50),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                ),
                Text(
                  'Person(s) to be Vetted',
                  style: TextStyle(
                      letterSpacing: 0.4,
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15),
                ),
                InkWell(

                  onTap: () {
                    Get.to(() => IncompletedVetScreen());
                  }, child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Icon(Icons.history, color: Colors.white),
                      Text('History', style: TextStyle(color: Colors.white,
                          fontSize: 11))
                    ],
                  ),
                ),
                ),
              ],
            ),
          ),

          SizedBox(height: 25),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Theme
                    .of(context)
                    .accentColor,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(30))),
                        padding: EdgeInsets.only(top: 5),
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 15),
                          child: Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded) {
                                              setState(() {
                                                expanded = false;
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration:
                                              Duration(milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder: (context, value, _) {
                                                return Container(
                                                  decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(0.3),
                                                        offset:
                                                        Offset(0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding:
                                                            const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 1',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize: 16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right: 15.0),
                                                        child: Icon(!expanded
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller: fNameController,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType.text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller: oNameController,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType.text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller: lNameController,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType.text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization.none,
                                                    keyboardType:
                                                    TextInputType.phone,
                                                    validator: (value) {
                                                      if (value.isEmpty ||
                                                          value.length != 11) {
                                                        return "Enter a valid phone number";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller: emailController,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization.none,
                                                    keyboardType: TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(
                                                          Icons.expand_more),
                                                      label: 'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType.text,
                                                      validator: (value) {
                                                        if (value.isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType.text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      suffixIcon: Icon(
                                                          Icons.expand_more),
                                                      controller:
                                                      terminalController,
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType.text,
                                                      validator: (value) {
                                                        if (value.isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    _selectImageOption(
                                                        onTapCamera: () async {
                                                          Get.back();
                                                          var selectedImage =
                                                          await PickImage
                                                              .openCamera();
                                                          if (selectedImage !=
                                                              null) {
                                                            setState(() {
                                                              picture =
                                                                  selectedImage
                                                                      .path;
                                                              _image =
                                                                  selectedImage;
                                                            });
                                                          }
                                                        },
                                                        onTapGallery: () async {
                                                          Get.back();

                                                          var selectedImage =
                                                          await PickImage
                                                              .openGallery();
                                                          if (selectedImage !=
                                                              null) {
                                                            setState(() {
                                                              picture =
                                                                  selectedImage
                                                                      .path;
                                                              _image =
                                                                  selectedImage;
                                                            });
                                                          }
                                                        });
                                                  },
                                                  child: _image == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(width: 10),
                                                      Text('Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image: FileImage(
                                                              _image!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                vetIIndex >= 2
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded2;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded2 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded2) {
                                              setState(() {
                                                expanded2 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded2 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 2',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded2
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController2,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController2,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController2,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController2,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController2,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController2,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController2,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      controller:
                                                      terminalController2,
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture2 =
                                                            selectedImage
                                                                .path;
                                                        _image2 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image2 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image2!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 3
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded3;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded3 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded3) {
                                              setState(() {
                                                expanded3 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded3 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 3',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded3
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController3,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController3,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController3,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController3,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController3,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController3,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController3,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      controller:
                                                      terminalController3,
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture3 =
                                                            selectedImage
                                                                .path;
                                                        _image3 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image3 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image3!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 4
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded4;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded4 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded4) {
                                              setState(() {
                                                expanded4 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded4 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 4',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded4
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController4,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController4,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController4,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController4,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController4,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController4,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController4,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      controller:
                                                      terminalController4,
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture4 =
                                                            selectedImage
                                                                .path;
                                                        _image4 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image4 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image4!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 5
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded5;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded5 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded5) {
                                              setState(() {
                                                expanded5 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded5 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 5',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded5
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController5,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController5,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController5,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController5,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController5,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController5,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController5,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      terminalController5,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture =
                                                            selectedImage
                                                                .path;
                                                        _image5 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image5 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image5!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 6
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded6;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded6 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded6) {
                                              setState(() {
                                                expanded6 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded6 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 6',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded6
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController6,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController6,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController6,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController6,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController6,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController6,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController6,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      terminalController6,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture6 =
                                                            selectedImage
                                                                .path;
                                                        _image6 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image6 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image6!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 7
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded7;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded7 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded7) {
                                              setState(() {
                                                expanded7 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded7 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 7',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded7
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController7,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController7,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController7,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController7,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController7,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController7,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController7,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      terminalController7,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture7 =
                                                            selectedImage
                                                                .path;
                                                        _image7 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image7 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image7!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 8
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded8;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded8 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded8) {
                                              setState(() {
                                                expanded8 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded8 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 8',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded8
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController8,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController8,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController8,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController8,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController8,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController8,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController8,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      terminalController8,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture8 =
                                                            selectedImage
                                                                .path;
                                                        _image8 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image8 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image8!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 9
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded9;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded9 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded9) {
                                              setState(() {
                                                expanded9 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded9 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 9',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded9
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController9,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController9,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController9,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController9,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController9,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController9,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController9,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      terminalController9,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture9 =
                                                            selectedImage
                                                                .path;
                                                        _image9 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image9 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image9!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                vetIIndex >= 10
                                    ? AnimatedContainer(
                                  onEnd: () {
                                    setState(() {
                                      removeView = !expanded10;
                                    });
                                  },
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.ease,
                                  alignment: Alignment.topCenter,
                                  height: expanded10 ? h : 40,
                                  child: SingleChildScrollView(
                                    physics:
                                    const NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            if (expanded10) {
                                              setState(() {
                                                expanded10 = false;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                    FocusNode());
                                              });
                                            } else {
                                              setState(() {
                                                expanded10 = true;
                                                // onOpenListener(index);
                                              });
                                            }
                                          },
                                          child: TweenAnimationBuilder(
                                              duration: Duration(
                                                  milliseconds: 500),
                                              tween: ColorTween(
                                                begin: Colors.white,
                                                end: Colors.grey[200],
                                              ),
                                              builder:
                                                  (context, value, _) {
                                                return Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: <
                                                        BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                            0.3),
                                                        offset: Offset(
                                                            0.4, 0.7),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      SizedBox(width: 20),
                                                      Expanded(
                                                        child: Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                bottom:
                                                                10.0),
                                                            child: Text(
                                                              'Person 10',
                                                              style: GoogleFonts
                                                                  .roboto(
                                                                  fontSize:
                                                                  16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .only(
                                                            right:
                                                            15.0),
                                                        child: Icon(!expanded10
                                                            ? Icons
                                                            .arrow_drop_down
                                                            : Icons
                                                            .arrow_drop_up),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                        ),
                                        Column(
                                          children: [
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    fNameController10,
                                                    obscure: false,
                                                    label: 'First Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "First name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    oNameController10,
                                                    obscure: false,
                                                    label: 'Other Name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,

                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    lNameController10,
                                                    obscure: false,
                                                    label: 'Last name',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Name cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.call,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    phoneNumberController10,
                                                    obscure: false,
                                                    label: 'Phone Number',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .phone,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Phone number cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.mail,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    emailController10,
                                                    obscure: false,
                                                    label: 'Email',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .none,
                                                    keyboardType:
                                                    TextInputType
                                                        .emailAddress,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.person,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showServiceOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      controller:
                                                      serviceController10,
                                                      obscure: false,
                                                      enabled: false,
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      label:
                                                      'Service type',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "service type cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InputFormField(
                                                    controller:
                                                    addressController10,
                                                    obscure: false,
                                                    label: 'Address',
                                                    textCapitalization:
                                                    TextCapitalization
                                                        .words,
                                                    keyboardType:
                                                    TextInputType
                                                        .text,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return "Address cannot be empty";
                                                      }
                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .location_on_rounded,
                                                  color: Colors.grey,
                                                ),
                                                Expanded(
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showTerminalOption(
                                                          context);
                                                    },
                                                    child: InputFormField(
                                                      suffixIcon: Icon(Icons
                                                          .expand_more),
                                                      controller:
                                                      terminalController10,
                                                      obscure: false,
                                                      enabled: false,
                                                      label: 'Location',
                                                      textCapitalization:
                                                      TextCapitalization
                                                          .words,
                                                      keyboardType:
                                                      TextInputType
                                                          .text,
                                                      validator: (value) {
                                                        if (value
                                                            .isEmpty) {
                                                          return "Location cannot be empty";
                                                        }
                                                        return null;
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Center(
                                              child: InkWell(
                                                  onTap: () async {
                                                    var selectedImage =
                                                    await PickImage
                                                        .openCamera();
                                                    if (selectedImage !=
                                                        null) {
                                                      setState(() {
                                                        picture10 =
                                                            selectedImage
                                                                .path;
                                                        _image10 =
                                                            selectedImage;
                                                      });
                                                    }
                                                  },
                                                  child: _image10 == null
                                                      ? Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: [
                                                      Icon(Icons
                                                          .file_upload),
                                                      SizedBox(
                                                          width:
                                                          10),
                                                      Text(
                                                          'Upload photo',
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontSize:
                                                              15,
                                                              fontWeight:
                                                              FontWeight.w700)),
                                                    ],
                                                  )
                                                      : Container(
                                                    height: 100,
                                                    width: 100,
                                                    decoration:
                                                    BoxDecoration(
                                                        shape: BoxShape
                                                            .circle,
                                                        image:
                                                        DecorationImage(
                                                          fit: BoxFit
                                                              .fill,
                                                          image:
                                                          FileImage(_image10!),
                                                        )),
                                                  )),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : Container(),
                                SizedBox(height: 35),
                                RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                          text:
                                          'By clicking “register”, you agree to all statements in',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 13,
                                          )),
                                      TextSpan(
                                        text: '\nTerms and Conditions',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 20),
                                Buttons.authButton(
                                    context: context,
                                    onTap: () {
                                      submit();
                                    },
                                    title: 'Push for Vetting'),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  submit() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      if (await InternetUtils.checkConnectivity()) {
        Dialogs.showLoading(context: context, text: 'Submitting..');
        var response = await VetServices.submitVets(
          id: id,
          phone: phoneNumberController.text,
          token: token,
          firstName: fNameController.text,
          clientId: clientId,
          serviceId: int.parse(serviceID),
          email: emailController.text,
          address: addressController.text,
          vetcity: vetCity,
          lastName: lNameController.text,
          picture: _image,
          otherName: oNameController.text,
          tenantId: tenantId,
          vetteeListID: vetteeListID,
        );
        if (vetIIndex >= 2) {
          var response2 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController2.text,
            token: token,
            firstName: fNameController2.text,
            clientId: clientId,
            serviceId: int.parse(serviceID2),
            email: emailController2.text,
            address: addressController2.text,
            lastName: lNameController2.text,
            picture: _image2,
            otherName: oNameController2.text,
            tenantId: tenantId,
            vetteeListID: vetteeListID2,
            vetcity: vetCity2,
          );
          print(response2);
        }
        if (vetIIndex >= 3) {
          var response3 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController3.text,
            token: token,
            firstName: fNameController3.text,
            clientId: clientId,
            serviceId: int.parse(serviceID3),
            email: emailController3.text,
            address: addressController3.text,
            lastName: lNameController3.text,
            picture: _image3,
            otherName: oNameController3.text,
            tenantId: tenantId,
            vetcity: vetCity3,
            vetteeListID: vetteeListID3,
          );
          print(response3);
        }
        if (vetIIndex >= 4) {
          var response4 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController4.text,
            token: token,
            firstName: fNameController4.text,
            clientId: clientId,
            serviceId: int.parse(serviceID4),
            email: emailController4.text,
            address: addressController4.text,
            lastName: lNameController4.text,
            picture: _image4,
            otherName: oNameController4.text,
            tenantId: tenantId,
            vetcity: vetCity4,
            vetteeListID: vetteeListID4,
          );
          print(response4);
        }
        if (vetIIndex >= 5) {
          var response5 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController5.text,
            token: token,
            firstName: fNameController5.text,
            clientId: clientId,
            serviceId: int.parse(serviceID5),
            email: emailController5.text,
            address: addressController5.text,
            lastName: lNameController5.text,
            picture: _image5,
            otherName: oNameController5.text,
            tenantId: tenantId,
            vetcity: vetCity5,
            vetteeListID: vetteeListID5,
          );
          print(response5);
        }
        if (vetIIndex >= 6) {
          var response6 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController6.text,
            token: token,
            firstName: fNameController6.text,
            clientId: clientId,
            serviceId: int.parse(serviceID6),
            email: emailController6.text,
            address: addressController6.text,
            lastName: lNameController6.text,
            picture: _image6,
            otherName: oNameController6.text,
            tenantId: tenantId,
            vetcity: vetCity6,
            vetteeListID: vetteeListID6,
          );
          print(response6);
        }
        if (vetIIndex >= 7) {
          var response7 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController7.text,
            token: token,
            firstName: fNameController7.text,
            clientId: clientId,
            serviceId: int.parse(serviceID7),
            email: emailController7.text,
            address: addressController7.text,
            lastName: lNameController7.text,
            picture: _image7,
            otherName: oNameController7.text,
            tenantId: tenantId,
            vetcity: vetCity7,
            vetteeListID: vetteeListID7,
          );
          print(response7);
        }
        if (vetIIndex >= 8) {
          var response8 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController8.text,
            token: token,
            firstName: fNameController8.text,
            clientId: clientId,
            serviceId: int.parse(serviceID8),
            email: emailController8.text,
            address: addressController8.text,
            lastName: lNameController8.text,
            picture: _image8,
            otherName: oNameController8.text,
            tenantId: tenantId,
            vetcity: vetCity8,
            vetteeListID: vetteeListID8,
          );
          print(response8);
        }
        if (vetIIndex >= 9) {
          var response9 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController9.text,
            token: token,
            firstName: fNameController9.text,
            clientId: clientId,
            serviceId: int.parse(serviceID9),
            email: emailController9.text,
            address: addressController9.text,
            lastName: lNameController9.text,
            picture: _image9,
            vetcity: vetCity9,
            otherName: oNameController9.text,
            tenantId: tenantId,
            vetteeListID: vetteeListID9,
          );
          print(response9);
        }
        if (vetIIndex >= 10) {
          var response10 = await VetServices.submitVets(
            id: id,
            phone: phoneNumberController10.text,
            token: token,
            firstName: fNameController10.text,
            clientId: clientId,
            serviceId: int.parse(serviceID10),
            email: emailController10.text,
            address: addressController10.text,
            lastName: lNameController10.text,
            picture: _image10,
            otherName: oNameController10.text,
            tenantId: tenantId,
            vetcity: vetCity10,
            vetteeListID: vetteeListID10,
          );
          print(response10);
        }
        print('response');
        print(response);

        if (response['shortDescription'] != 'SUCCESS') {
          Get.back();
          Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
        } else if (response['shortDescription'] == 'SUCCESS') {
          Get.back();
          Get.to(
                () => PendingVetScreen(),
          );
        } else {
          Dialogs.showErrorSnackBar('Error!', 'Failed to submit, try again');
        }
      } else
        Dialogs.showErrorSnackBar('No Internet', 'Check yur connectivity');
    } else
      Dialogs.showErrorSnackBar('Error!', 'Filled all required fields');
  }
}
