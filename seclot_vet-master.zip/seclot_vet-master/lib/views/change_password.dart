import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/services/user_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/views/homepage.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import 'input_fields.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({Key? key}) : super(key: key);

  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  TextEditingController passwordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  bool _showPassword = false;
  UserController userController = Get.find();
  String token = '';

  @override
  void initState() {
    token = userController.getToken();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // SizedBox(height: 50),
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.west,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                    ),
                    Text(''),
                    SizedBox(width: 30),
                  ],
                ),
              ),
              SizedBox(height: 25),
              Expanded(
                child: Container(
                  // height: MediaQuery.of(context).size.height * 0.8,
                  decoration: BoxDecoration(
                    color: Theme.of(context).accentColor,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(30)),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 20, 0, 25),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Change Password',
                                style: GoogleFonts.roboto(color:Colors.white,
                                    fontSize: 18, fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(30))),
                          padding: EdgeInsets.symmetric(vertical: 20),
                          child: SingleChildScrollView(
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  SizedBox(height: 35),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.security_outlined,
                                        color: Colors.grey,
                                      ),
                                      Expanded(
                                        child: InputFormField(
                                          enabled: !isLoading,
                                          controller: passwordController,
                                          obscure: !_showPassword,
                                          label: 'Password',
                                          textCapitalization:
                                              TextCapitalization.none,
                                          keyboardType:
                                              TextInputType.emailAddress,
                                          suffixIcon: IconButton(
                                            onPressed: () {
                                              setState(() =>
                                              _showPassword = !_showPassword);
                                            },
                                            icon: !_showPassword
                                                ? Text(
                                              'Show',
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 11),
                                            )
                                                : Text(
                                              'Hide',
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 11),
                                            ),
                                          ),

                                          validator: (value) {
                                            if (value.isEmpty||value.length <6) {
                                              return "Please enter a valid password";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.security_outlined,
                                        color: Colors.grey,
                                      ),
                                      Expanded(
                                        child: InputFormField(
                                          enabled: !isLoading,
                                          controller: newPasswordController,
                                          obscure: !_showPassword,
                                          label: 'New password',
                                          textCapitalization:
                                              TextCapitalization.none,
                                          keyboardType:
                                              TextInputType.emailAddress,
                                          suffixIcon: IconButton(
                                            onPressed: () {
                                              setState(() =>
                                              _showPassword = !_showPassword);
                                            },
                                            icon: !_showPassword
                                                ? Text(
                                              'Show',
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 11),
                                            )
                                                : Text(
                                              'Hide',
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 11),
                                            ),
                                          ),

                                          validator: (value) {
                                            if (value.isEmpty||value.length <6) {
                                              return "Please enter a valid name";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.security_outlined,
                                        color: Colors.grey,
                                      ),
                                      Expanded(
                                        child: InputFormField(
                                          enabled: !isLoading,
                                          controller: confirmPasswordController,
                                          obscure: !_showPassword,
                                          label: 'Confirm password',
                                          textCapitalization:
                                              TextCapitalization.none,
                                          keyboardType:
                                              TextInputType.emailAddress,
                                          suffixIcon: IconButton(
                                            onPressed: () {
                                              setState(() =>
                                              _showPassword = !_showPassword);
                                            },
                                            icon: !_showPassword
                                                ? Text(
                                              'Show',
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 11),
                                            )
                                                : Text(
                                              'Hide',
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 11),
                                            ),
                                          ),

                                          validator: (value) {
                                            if (confirmPasswordController.text !=newPasswordController.text) {
                                              return "Password does\'t match";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 30),
                                  Buttons.authButton(
                                      context: context,
                                      onTap: () {
                                        changePassword();
                                      },
                                      title: 'Save Password'),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  changeLoadingState() {
    setState(() {
      isLoading = !isLoading;
    });
  }

  changePassword() async {
    if (await InternetUtils.checkConnectivity()) {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        setState(() {
          isLoading = true;
        });
        var response = await UserServices.changePassword(
            token: token,
            currentPassword: passwordController.text,
            newPassword: newPasswordController.text,
            confirmPassword: confirmPasswordController.text);
        print(response);
        if (response is String) {
          changeLoadingState();
          if (response.contains('HttpException') || response.contains('Socket'))
            Dialogs.showErrorSnackBar('Error!', 'Failed, please try again');
          else
            Dialogs.showErrorSnackBar('Error!', response);
        }else if(response['code']!='200'){
          Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
        }
        else {
          Get.back();
          Dialogs.showSuccessSnackBar(
              'Success', 'Password changed successfully');
        }
      } else {
        Dialogs.showErrorSnackBar('Error', 'Please enter valid password');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'No Internet!', 'Please check your internet connection.');
      changeLoadingState();
    }
    setState(() {
      isLoading = false;
    });
  }
}
