import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:seclot_vet/views/login_screen.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OnBoardingInfo {
  final imageAsset;
  final title;
  final description;

  OnBoardingInfo(this.imageAsset, this.title, this.description);
}

class OnBoardingController extends GetxController {
  var selectedPageIndex = 0.obs;

  bool get isLastPage => selectedPageIndex.value == onBoardingPages.length - 1;
  var pageController = PageController();

  forwardAction() {
    if (isLastPage) {
    } else
      pageController.nextPage(duration: 300.milliseconds, curve: Curves.ease);
  }

  List<OnBoardingInfo> onBoardingPages = [
    OnBoardingInfo('assets/images/onboard1.png', 'Address verification',
        'Verify any address with a few clicks.'),
    OnBoardingInfo('assets/images/onboard2.png', 'KYC',
        'Know who you are about to deal with.'),
  ];
}

class OnBoardingScreen extends StatelessWidget {
  final _controller = OnBoardingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            PageView.builder(
                controller: _controller.pageController,
                onPageChanged: _controller.selectedPageIndex,
                itemCount: _controller.onBoardingPages.length,
                itemBuilder: (context, index) {
                  return Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          _controller.onBoardingPages[index].imageAsset,
                          width: size.width * 0.65,
                          fit: BoxFit.contain,
                        ),
                        SizedBox(height: 60),
                        Text(
                          _controller.onBoardingPages[index].title,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w700),
                        ),
                        SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 64.0),
                          child: Text(
                            _controller.onBoardingPages[index].description,
                            textAlign: TextAlign.center,
                          ),
                        ),
                        SizedBox(height: 20),
                      ],
                    ),
                  );
                }),
            Positioned(
              // right: 20,
              bottom: 30,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 30),
                width: size.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _controller.onBoardingPages.length,
                        (index) => Obx(() {
                          return Container(
                            margin: const EdgeInsets.all(5),
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  _controller.selectedPageIndex.value == index
                                      ? Theme.of(context).primaryColor
                                      : Colors.grey.withOpacity(0.4),
                              // shape: BoxShape.circle,
                            ),
                          );
                        }),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        _controller.isLastPage
                            ? Get.to(() => WelcomeScreen())
                            : _controller.forwardAction();
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 15.0, vertical: 15),
                        child: Center(
                          child: Text(
                            'Next',
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

// goToWelcome()async{
//   Get.offNamedUntil(Routes.getStarted, (route) => false);
//   SharedPreferences prefs = await SharedPreferences.getInstance();
//   await prefs.setString('isNewUser', 'No');
// }
}

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            SizedBox(height: 30),
            Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/images/onboard3.png',
                    width: size.width * 0.65,
                    fit: BoxFit.contain,
                  ),
                  SizedBox(height: 60),
                  Text(
                    'Accessibility',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 64.0),
                    child: Text(
                      'Access you account anywhere on any device.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
            Buttons.authButton(
                context: context,
                onTap: () {
                  Get.to(() => LogInScreen());
                },
                title: 'Get Started'),
          ],
        ),
      ),
    );
  }

// goToWelcome()async{
//   Get.offNamedUntil(Routes.getStarted, (route) => false);
//   SharedPreferences prefs = await SharedPreferences.getInstance();
//   await prefs.setString('isNewUser', 'No');
// }
}
