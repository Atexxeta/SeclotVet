import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class QueueDetailScreen extends StatefulWidget {
  const QueueDetailScreen({Key? key}) : super(key: key);

  @override
  _QueueDetailScreenState createState() => _QueueDetailScreenState();
}

class _QueueDetailScreenState extends State<QueueDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Column(
        children: [
          // SizedBox(height: 50),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                ),
                Text(''),
                SizedBox(width: 30),
              ],
            ),
          ),

          SizedBox(height: 25),
          Expanded(
            child: Container(
              // height: MediaQuery.of(context).size.height * 0.8,
              decoration: BoxDecoration(
                color: Theme.of(context).accentColor,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 20, 0, 25),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            'Person to be Vetted',
                            style: GoogleFonts.roboto(
                                fontSize: 18, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(30))),
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 10),
                              Row(
                                children: [
                                  Container(
                                    height: 118,
                                    width: 118,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                            'assets/images/profile_image.png'),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 20),
                                  Expanded(
                                    child: idWidget('Tracking ID', 'SEC00587'),
                                  ),
                                ],
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(15, 20, 5, 20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    detailWidget('Name', 'John Willie'),
                                    detailWidget(
                                        'Phone Number', '+2348109892800'),
                                    SizedBox(height: 10),
                                    detailWidget('LGA', 'Mushin LGA'),
                                    SizedBox(height: 10),
                                    detailWidget('State', 'Lagos State'),
                                    SizedBox(height: 10),
                                    detailWidget('Address',
                                        '5, Idowu Cresent, Idumota, Lagos.'),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  detailWidget(title, desc) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(color: Colors.black54, fontSize: 13),
              ),
              SizedBox(height: 3),
              Text(
                desc,
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
        Divider(
          thickness: 0.5,
          color: Colors.grey.withOpacity(0.8),
        ),
      ],
    );
  }

  idWidget(title, desc) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(color: Colors.black54, fontSize: 13),
        ),
        SizedBox(height: 3),
        Text(
          desc,
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}
