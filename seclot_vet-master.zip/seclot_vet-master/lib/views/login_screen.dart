import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/services/auth_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../routes.dart';
import 'forgot_password.dart';
import 'input_fields.dart';
import 'register_screen.dart';

class LogInScreen extends StatefulWidget {
  const LogInScreen({Key? key}) : super(key: key);

  @override
  _LogInScreenState createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  bool _showPassword = false;

  bool isLoading = false;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  UserController userController = Get.put(UserController(), permanent: true);

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    getSecureStorage();
    super.initState();
  }

  void getSecureStorage() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    // final isUsingBio = prefs.getString('usingBiometric');
    // if (isUsingBio != null) {
    //   setState(() {
    //     userStoredBiometric = isUsingBio == 'true';
    //     usePassword =false;
    //   });
    // }
    // if (userStoredBiometric == true)
    //   Future.delayed(Duration(seconds: 1),(){
    //     _authenticate();
    //
    //   });
    // else {
    final userStoredEmail = prefs.getString('userEmail');
    final userStoredPassword = prefs.getString('userPassword');
    if (userStoredPassword != null && userStoredEmail != null) {
      setState(() {
        emailController.text = userStoredEmail;
        passwordController.text = userStoredPassword;
        // email = userStoredEmail;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              SizedBox(height: 80),
              Image.asset(
                'assets/images/seclot_logo.png',
                width: MediaQuery.of(context).size.width * 0.61,
              ),
              SizedBox(height: 45),
              Expanded(
                child: Container(
                  // height: MediaQuery.of(context).size.height * 0.8,
                  decoration: BoxDecoration(
                      color: Theme.of(context).accentColor,
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(30))),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 25.0),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Login Details',
                                style: GoogleFonts.roboto(color:Colors.white,
                                    fontSize: 18, fontWeight: FontWeight.w700),
                              ),
                            ),
                            Text(
                              'Kindly input your login details below.',
                              style: GoogleFonts.roboto(color:Colors.white,
                                  fontSize: 14, fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(30))),
                          padding: EdgeInsets.symmetric(
                              horizontal: 15, vertical: 20),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                SizedBox(height: 20),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.mail_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: emailController,
                                        obscure: false,
                                        label: 'Email',
                                        textCapitalization:
                                            TextCapitalization.none,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                        suffixIcon: emailController.text.isEmpty
                                            ? Text('')
                                            : emailController.text.isNotEmpty &&
                                                    emailController.text
                                                        .contains('@') &&
                                                    emailController.text
                                                        .contains('.')
                                                ? Icon(
                                                    Icons.done,
                                                    color: Colors.greenAccent,
                                                  )
                                                : Icon(
                                                    Icons.close,
                                                    color: Colors.redAccent,
                                                  ),
                                        validator: (value) {
                                          if (value.isEmpty ||
                                              !value.contains('@') ||
                                              !value.contains('.')) {
                                            return "Please enter a valid email";
                                          }
                                          return null;
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.security_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: passwordController,
                                        obscure: !_showPassword,
                                        validator: (value) {
                                          if (value.isEmpty ||
                                              value.length < 4) {
                                            return "Please enter a valid password";
                                          }
                                          return null;
                                        },
                                        label: 'Password',
                                        textCapitalization:
                                            TextCapitalization.none,
                                        suffixIcon: IconButton(
                                          onPressed: () {
                                            setState(() =>
                                                _showPassword = !_showPassword);
                                          },
                                          icon: !_showPassword
                                              ? Text(
                                                  'Show',
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 11),
                                                )
                                              : Text(
                                                  'Hide',
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 11),
                                                ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 45),
                                Buttons.authButton(
                                    context: context,
                                    onTap: () {
                                      // Get.to(() => HomeScreen());
                                      signIn();
                                    },
                                    title: isLoading ? 'Logging in' : 'Login'),
                                SizedBox(height: 15),
                                InkWell(
                                  onTap: () {
                                    Get.to(() => ForgotPassword());
                                  },
                                  child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Text(
                                        'Forgot password?',
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 45),
                                Center(
                                  child: InkWell(
                                    onTap: () {
                                      Get.to(() => RegisterScreen());
                                    },
                                    child: RichText(
                                      text: TextSpan(
                                        children: [
                                          TextSpan(
                                              text: 'Don\'t have an account?',
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 13,
                                              )),
                                          TextSpan(
                                            text: ' Sign up',
                                            style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  changeLoadingState() {
    setState(() {
      isLoading = !isLoading;
    });
  }

  signIn() async {
    if (await InternetUtils.checkConnectivity()) {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        setState(() {
          isLoading = true;
        });
        Dialogs.showLoading(context: context, text: 'Login in..');
        var response = await AuthenticationService.login(
            email: emailController.text, password: passwordController.text);
        print(response);

        if (response is String) {
          Get.back();
          changeLoadingState();
          if (response.contains('HttpException') || response.contains('Socket'))
            Dialogs.showErrorSnackBar(
                'Error!', 'Failed to log in, please try again');
          else
            Dialogs.showErrorSnackBar('Error!', response);
        } else if (response['shortDescription'] != 'SUCCESS') {
          Get.back();

          Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
        } else {
          var token = response['object']['token'];

          await userController.setToken(token);
          var profile = await AuthenticationService.getProfile(token);
          print('======== profile=========>');

          print(profile);
          if (profile is String) {
            Get.back();

            changeLoadingState();

            Dialogs.showErrorSnackBar('Error!', profile);
          } else if (response['shortDescription'] != 'SUCCESS') {
            Get.back();

            Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
          } else if (response['code'] != '200') {
            Get.back();

            Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
          }
          Get.back();

          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('userEmail', emailController.text);
          await prefs.setString('userPassword', passwordController.text);
          Get.offNamedUntil(Routes.dashboard, (Route<dynamic> route) => false);

          await userController.setUserDetails(profile);
          Dialogs.showNoticeSnackBar(
              'Congratulation!', 'Welcome ${profile['object']['firstName']}');
        }
      } else {
        Dialogs.showErrorSnackBar(
            'Error', 'Please enter valid email & password');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'No Internet!', 'Please check your internet connection.');
    }
    setState(() {
      isLoading = false;
    });
  }
}
