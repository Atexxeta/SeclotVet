import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/services/user_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import 'input_fields.dart';
import 'login_screen.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);

  @override
  _ForgotPasswordState createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  bool isLoading = false;
  bool setPass = false;
  final emailController = TextEditingController();
  final otpController = TextEditingController();
  final passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                        onTap: () {
                          Get.back();
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Icon(
                            Icons.west,
                            color: Colors.white,
                            size: 25,
                          ),
                        )),
                    SizedBox(height: 80),
                  ],
                ),
              ),
              Image.asset(
                'assets/images/seclot_logo.png',
                width: MediaQuery.of(context).size.width * 0.20,
              ),
              SizedBox(height: 45),
              Expanded(
                child: Container(
                  // height: MediaQuery.of(context).size.height * 0.8,
                  decoration: BoxDecoration(
                      color: Theme.of(context).accentColor,
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(30))),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 25.0),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Forgot Password?',
                                style: GoogleFonts.roboto(color:Colors.white,
                                    fontSize: 18, fontWeight: FontWeight.w700),
                              ),
                            ),
                            Text(
                              'Enter the email you registered with',
                              style: GoogleFonts.roboto(color:Colors.white,
                                  fontSize: 14, fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(30))),
                          padding: EdgeInsets.symmetric(
                              horizontal: 15, vertical: 20),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                SizedBox(height: 20),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.mail_outlined,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: !isLoading,
                                        controller: emailController,
                                        obscure: false,
                                        label: 'Email',
                                        textCapitalization:
                                            TextCapitalization.none,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                        suffixIcon: emailController.text.isEmpty
                                            ? Text('')
                                            : emailController.text.isNotEmpty &&
                                                    emailController.text
                                                        .contains('@') &&
                                                    emailController.text
                                                        .contains('.')
                                                ? Icon(
                                                    Icons.done,
                                                    color: Colors.greenAccent,
                                                  )
                                                : Icon(
                                                    Icons.close,
                                                    color: Colors.redAccent,
                                                  ),
                                        validator: (value) {
                                          if (value.isEmpty ||
                                              !value.contains('@') ||
                                              !value.contains('.')) {
                                            return "Please enter a valid email";
                                          }
                                          return null;
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                if (setPass)
                                  Column(
                                    children: [
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.password,
                                            color: Colors.grey,
                                          ),
                                          Expanded(
                                            child: InputFormField(
                                              enabled: !isLoading,
                                              controller: otpController,
                                              obscure: false,
                                              label: 'OTP',
                                              textCapitalization:
                                                  TextCapitalization.none,
                                              keyboardType:
                                                  TextInputType.number,
                                              validator: (value) {
                                                if (value.isEmpty) {
                                                  return "Please enter a valid OTP";
                                                }
                                                return null;
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.lock,
                                            color: Colors.grey,
                                          ),
                                          Expanded(
                                            child: InputFormField(
                                              enabled: !isLoading,
                                              controller: passwordController,
                                              obscure: false,
                                              label: 'New password',
                                              textCapitalization:
                                                  TextCapitalization.none,
                                              keyboardType:
                                                  TextInputType.emailAddress,
                                              suffixIcon: passwordController
                                                      .text.isEmpty
                                                  ? Text('')
                                                  : passwordController.text
                                                              .isNotEmpty &&
                                                          passwordController
                                                                  .text.length >
                                                              5
                                                      ? Icon(
                                                          Icons.done,
                                                          color: Colors
                                                              .greenAccent,
                                                        )
                                                      : Icon(
                                                          Icons.close,
                                                          color:
                                                              Colors.redAccent,
                                                        ),
                                              validator: (value) {
                                                if (value.isEmpty ||
                                                    value.length < 5) {
                                                  return "Please enter a valid password";
                                                }
                                                return null;
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                SizedBox(height: 45),
                                Buttons.authButton(
                                    context: context,
                                    onTap: () {
                                      // Get.to(() => HomeScreen());
                                      !setPass ? forgotPass() : reset();
                                    },
                                    title: !setPass ? 'Reset' : 'Submit'),
                                SizedBox(height: 15),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  changeLoadingState() {
    setState(() {
      isLoading = !isLoading;
    });
  }

  forgotPass() async {
    if (await InternetUtils.checkConnectivity()) {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        setState(() {
          isLoading = true;
        });
        Dialogs.showLoading(context: context, text: 'Processing..');

        var response =
            await UserServices.resetPassword(email: emailController.text);
        print(response);
        if (response is String) {
          Get.back();

          changeLoadingState();
          if (response.contains('HttpException') || response.contains('Socket'))
            Dialogs.showErrorSnackBar('Error!', 'Failed, please try again');
          else
            Dialogs.showErrorSnackBar('Error!', response);
        } else if (response['code'] != '200') {
          Get.back();

          Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
        } else if (response['code'] != '200') {
          Get.back();

          Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
        } else {
          Get.back();

          Dialogs.showSuccessDialog(
              context: context,
              message: 'Check your email for the reset OTP',
              action: () {
                Get.back();
                setState(() {
                  setPass = true;
                });
              },
              actionText: 'Ok');
        }
      } else {
        Dialogs.showErrorSnackBar('Error', 'Please enter valid email');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'No Internet!', 'Please check your internet connection.');
      changeLoadingState();
    }
    setState(() {
      isLoading = false;
    });
  }

  reset() async {
    if (await InternetUtils.checkConnectivity()) {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        setState(() {
          isLoading = true;
        });
        Dialogs.showLoading(context: context, text: 'Processing..');

        var response = await UserServices.setNewPassword(
            email: emailController.text,
            code: otpController.text,
            password: passwordController.text);
        print(response);
        if (response is String) {
          Get.back();

          changeLoadingState();
          if (response.contains('HttpException') || response.contains('Socket'))
            Dialogs.showErrorSnackBar('Error!', 'Failed, please try again');
          else
            Dialogs.showErrorSnackBar('Error!', response);
        } else if (response['code'] != '200') {
          Get.back();

          Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
        } else if (response['code'] != '200') {
          Get.back();

          Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
        } else {
          Get.back();

          Dialogs.showSuccessDialog(
              context: context,
              message: 'Password reset successfully.',
              action: () {
                Get.back(closeOverlays: true);
                Get.offAll(() => LogInScreen());
              },
              actionText: 'Ok');
        }
      } else {
        Dialogs.showErrorSnackBar('Error', 'Please enter valid email');
      }
    } else {
      Dialogs.showErrorSnackBar(
          'No Internet!', 'Please check your internet connection.');
      changeLoadingState();
    }
    setState(() {
      isLoading = false;
    });
  }
}
