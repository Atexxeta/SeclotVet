import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/views/change_password.dart';
import 'package:seclot_vet/views/login_screen.dart';
import 'package:seclot_vet/views/profile.dart';
import 'package:share/share.dart';

import 'subscription_screen.dart';

class SideDrawer extends StatelessWidget {
  final UserController userController = Get.find();
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height,
      width: size.width,
      color: Theme.of(context).scaffoldBackgroundColor,
      child: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 50),
              drawerOption(
                title: 'Personal Information',
                icon: Icons.manage_accounts,
                onTap: () {
                  Get.back();
                  Get.to(() => ProfileScreen());
                },
              ),
              drawerOption(
                title: 'Subscription',
                icon: Icons.loyalty,
                onTap: () {
                  Get.back();

                  Get.to(() => SubscriptionScreen());
                },
              ),
              Builder(
                builder: (BuildContext context) {
                  return drawerOption(
                    title: 'Share',
                    icon: Icons.connect_without_contact,
                    onTap: () {
                      Get.back();

                      share(context);
                    },
                  );
                },
              ),
              // drawerOption(
              //   title: 'Feedback',
              //   icon: Icons.record_voice_over,
              //   onTap: () {
              //     Get.back();
              //   },
              // ),
              drawerOption(
                title: 'Change Password',
                icon: Icons.lock,
                onTap: () {
                  Get.back();
                  Get.to(() => ChangePasswordScreen());
                },
              ),
              SizedBox(height: 5),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: InkWell(
                  onTap: () {
                    userController.logOut();
                  },
                  child: Row(
                    children: [
                      Image.asset(
                        'assets/icons/logout.png',
                        height: 20,
                        color: Colors.grey,
                      ),
                      SizedBox(width: 30),
                      Expanded(
                        child: Text(
                          'Logout',
                          style: TextStyle(fontSize: 15),
                        ),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  drawerOption({title, onTap, icon}) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(0, 2, 0, 2),
          child: ListTile(
            onTap: onTap,
            leading: Icon(icon),
            title: Text(
              title,
              style: TextStyle(fontSize: 15),
            ),
          ),
        ),
        Divider(
          color: Colors.grey.withOpacity(0.5),
          thickness: 0.8,
        ),
      ],
    );
  }

  String text =
      'Use Seclot vet to verify the detail and credentias of your employee and staff. Download it today on Google play store and iOS app store for free';

  share(BuildContext context) {
    final RenderBox box = context.findRenderObject() as RenderBox;
    Share.share(text,
        subject: text,
        sharePositionOrigin: box.localToGlobal(Offset.zero) & box.size);
  }
}
