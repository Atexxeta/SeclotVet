// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:flutter_paystack/flutter_paystack.dart';
// import 'package:seclot_vet/controllers/user_controller.dart';
// import 'package:seclot_vet/services/paystack_services.dart';
// import 'package:seclot_vet/utils/internet_utils.dart';
// import 'package:seclot_vet/widgets/button.dart';
// import 'package:seclot_vet/widgets/dialogs.dart';
//
// import 'input_fields.dart';
//
// class AddMoney extends StatefulWidget {
//   @override
//   _AddMoneyState createState() => _AddMoneyState();
// }
//
// class _AddMoneyState extends State<AddMoney> {
//
//   final plugin = PaystackPlugin();
//
//   TextEditingController cardController = TextEditingController();
//   TextEditingController bankController = TextEditingController();
//   TextEditingController amountController = TextEditingController();
//   TextEditingController currencyController = TextEditingController();
//   TextEditingController providerController = TextEditingController();
//   final _formKey = GlobalKey<FormState>();
//
//   UserController userController = Get.find();
//
//   String token = '';
//   var userDetail;
//   String email = '';
//   String card = '';
//   String bank = '';
//   String cardId = '';
//   String accountNumber = '';
//   bool error = false;
//   String errMsg = '';
//
//   @override
//   void initState() {
//     boot();
//     plugin.initialize(publicKey: PaystackConst.publicKeyTest);
//     super.initState();
//   }
//
//   void boot() async {
//     token = await userController.getToken();
//     userDetail = await userController.getUser();
//     setState(() {
//       currencyController.text = userDetail.currencyCode.toString();
//       email = userDetail.email;
//     });
//
//   }
//
//   bool isGeneratingCode = false;
//   String paystackRef = '';
//   String paystackAccesToken = '';
//
//   chargeCard() async {
//     int amount = int.parse(totalAmount) * 100;
//     setState(() {
//       isGeneratingCode = !isGeneratingCode;
//     });
//
//     print(amountController.text);
//     Map accessCode =
//     await PaymentServices.createPayStackAccessCode(email, amount);
//
//     print('accessCode');
//     print(accessCode);
//     print(accessCode["data"]["access_code"]);
//     setState(() {
//       isGeneratingCode = !isGeneratingCode;
//     });
//
//     Charge charge = Charge()
//       ..amount = amount
//       ..accessCode = accessCode["data"]["access_code"]
//       ..email = email;
//
//     print('charge');
//     print(charge);
//
//     CheckoutResponse response = await plugin.checkout(
//       context,
//       method:
//       CheckoutMethod.selectable, // Defaults to CheckoutMethod.selectable
//       charge: charge,
//       logo:Image.asset('assets/images/seclot_logo.png',height: 35,),
//       fullscreen: true,
//     );
//
//     print('final response');
//     print(response);
//     if (response.status == true) {
//       Dialogs.showSuccessDialog(
//           context: context,
//           message: 'Payment was successfully',
//           actionText:'Great',
//           action: () {
//             Get.back();
//             setState(() {
//               paystackRef = response.reference!;
//             });
//             addMoney();
//             print(paystackRef);
//           });
//     } else {
//       if (response.message == 'Access Code does not match public key') {
//         Dialogs.showErrorSnackBar(
//           'Failed',' Please try again later.',
//         );
//       } else {
//         Dialogs.showErrorSnackBar(
//           'Error', response.message,
//         );
//       }
//     }
//   }
//
//   doNothing() {
//     print('Do nothing');
//   }
//
//   @override
//   void dispose() {
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: GestureDetector(
//         onTap: () {
//           FocusScope.of(context).unfocus();
//         },
//         child: Form(
//           key: _formKey,
//           child: Column(
//             children: [
//               Padding(
//                 padding: EdgeInsets.only(bottom: 20),
//                 child:
//                 DesignUtils.buildBackAppBar(context, 'Add Money to Wallet'),
//               ),
//               Expanded(
//                 child: Padding(
//                   padding:
//                   EdgeInsets.symmetric(horizontal: 20),
//                   child: SingleChildScrollView(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Expanded(
//                                 flex: 2,
//                                 child: InputFormField(
//                                   enabled: false,
//                                   controller: currencyController,
//                                   obscure: false,
//                                   suffixIcon:
//                                   Icon(Icons.keyboard_arrow_down_rounded),
//                                   textCapitalization: TextCapitalization.words,
//                                   keyboardType: TextInputType.phone,
//                                   label: 'Select currency',
//                                 ),
//                               ),
//                               Expanded(
//                                 flex: 3,
//                                 child: InputFormField(
//                                   controller: amountController,
//                                   obscure: false,
//
//                                   textCapitalization: TextCapitalization.words,
//                                   keyboardType: TextInputType.phone,
//                                   label: 'Amount',
//                                 ),
//                               ),
//                             ],
//                           ),
//
//                           SizedBox(
//                               height: MediaQuery.of(context).size.height * 0.05),
//
//                               SizedBox(height: 30),
//                               Buttons.authButton(
//                                   context: context,
//                                   onTap: () {
//                                     // add();
//                                   },
//                                   title: 'Add money'),
//                             ],
//                           ),
//
//                       )),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   bool isLoading = false;
//
//   changeLoadingState() {
//     setState(() {
//       isLoading = !isLoading;
//     });
//   }
//
// }
