import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/controllers/vet_controller.dart';
import 'package:seclot_vet/services/auth_services.dart';
import 'package:seclot_vet/services/user_services.dart';
import 'package:seclot_vet/utils/internet_utils.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import '../main.dart';
import 'input_fields.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController issueDateCOntroller = TextEditingController();
  TextEditingController expiryDateCOntroller = TextEditingController();
  TextEditingController dobController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController genderController = TextEditingController();
  TextEditingController identityController = TextEditingController();
  TextEditingController identityNumberController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isEdited = false;
  UserController userController = Get.find();
  VetController vetController = Get.put(VetController());
  String token = '';
  String name = '';
  String profilePic = '';
  String userId = '';
  File? _image;
  File? _idImage;
  var terminals=[];

  @override
  void initState() {
    token = userController.getToken();
    var user = userController.getUser();
    boot();

    setState(() {
      userId = user.userId;
      profilePic = (user.photo == 'null' || user.photo == '')
          ? userController.getLogo()
          : user.photo;
      firstNameController.text = user.firstName == 'null' ? '' : user.firstName;
      lastNameController.text = user.lastName == 'null' ? '' : user.lastName;
      name = '${firstNameController.text} ${lastNameController.text}';
      emailController.text = user.email == 'null' ? '' : user.email;
      phoneController.text = user.phoneNumber == 'null' ? '' : user.phoneNumber;
      dobController.text = user.dateOfBirth == 'null' ? '' : user.dateOfBirth;
      addressController.text = user.address == 'null' ? '' : user.address;
      issueDateCOntroller.text = user.idIssueDate == 'null'
          ? ''
          : DateFormat('yyyy-MM-dd')
              .format(DateTime.parse(user.idIssueDate))
              .toString();
      expiryDateCOntroller.text = user.idExpireDate == 'null'
          ? ''
          : DateFormat('yyyy-MM-dd')
              .format(DateTime.parse(user.idExpireDate))
              .toString();
      var gender = user.gender == 'null' ? '' : user.gender;
      genderController.text = gender == '0' ? 'Male' : 'Female';
      identityNumberController.text =
          user.identificationCode == 'null' ? '' : user.identificationCode;
      var identity =
          user.identificationCode == 'null' ? '' : user.identificationCode;
      identityController.text = identity == '1'
          ? 'Passport'
          : identity == '2'
              ? 'Driver License'
              : identity == '3'
                  ? 'National ID'
                  : identity == '4'
                      ? 'Social Security'
                      : identity == '6'
                          ? 'Voter\'s Card'
                          : 'BVN';
    });
    print(token);
    print(genderController.text);
    super.initState();
  }

  boot() async {
    print(terminals);
    var t = await vetController.getAllTerminals(token);
    setState(() {
      terminals = t;
    });
  }

  Future _showTerminalOption() {
    return showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom),
                height: MediaQuery.of(context).size.height * 0.4,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                ),
                child: _buildTerminalMenu(),
              ),
            ));
  }

  _buildTerminalMenu() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
          color: Theme.of(context).scaffoldBackgroundColor),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Center(
                child: Text(
                  'Select a Location',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).primaryColor),
                ),
              ),
            ),
          ),
          Divider(),
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                child: Column(
                  children: List<Widget>.generate(terminals.length, (index) {
                    var item = terminals[index];
                    return new ListTile(
                      onTap: () => _selectTerminal(item),
                      title: Text(
                        item['name'],
                        softWrap: true,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: locationController.text == item['name']
                              ? FontWeight.w600
                              : FontWeight.w500,
                        ),
                      ),
                      trailing: locationController.text == item['name']
                          ? Icon(Icons.circle,
                              size: 15, color: Theme.of(context).primaryColor)
                          : Text(''),
                    );
                  }),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String vetCity = '';

  void _selectTerminal(item) {
    Get.back();

    setState(() {
      vetCity = item['id'].toString();
      locationController.text = item['name'];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.west,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                    ),
                    Text(''),
                    SizedBox(width: 30),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Expanded(
                child: Container(
                  // height: MediaQuery.of(context).size.height * 0.8,
                  decoration: BoxDecoration(
                    color: Theme.of(context).accentColor,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(30)),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 5, 0, 10),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Personal Information',
                                style: GoogleFonts.roboto(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(30))),
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: SingleChildScrollView(
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  SizedBox(height: 5),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Stack(
                                        children: [
                                          _image == null
                                              ? Container(
                                                  margin: EdgeInsets.all(3),
                                                  height: 118,
                                                  width: 118,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                        fit: BoxFit.contain,
                                                        image: NetworkImage(
                                                            profilePic)),
                                                  ),
                                                )
                                              : Container(
                                                  margin: EdgeInsets.all(3),
                                                  height: 118,
                                                  width: 118,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                      fit: BoxFit.contain,
                                                      image: FileImage(_image!),
                                                    ),
                                                  ),
                                                ),
                                          Positioned(
                                              bottom: 5,
                                              right: 0,
                                              child: InkWell(
                                                  onTap: () async {
                                                    if (isEdited) {
                                                      var selectedImage =
                                                          await PickImage
                                                              .openGallery();
                                                      print('selectedImage');
                                                      print(selectedImage);

                                                      if (selectedImage !=
                                                          null) {
                                                        setState(() {
                                                          profilePic =
                                                              selectedImage
                                                                  .path;
                                                          _image =
                                                              selectedImage;
                                                          print(profilePic);
                                                        });
                                                      }
                                                    }
                                                  },
                                                  child: Container(
                                                      decoration: BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          color: Colors.black),
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(6.0),
                                                        child: Icon(
                                                            Icons.add_a_photo,
                                                            size: 20,
                                                            color:
                                                                Colors.white),
                                                      )))),
                                        ],
                                      ),
                                      SizedBox(height: 5),
                                      Column(
                                        children: [
                                          Text(
                                            '$name',
                                            style: TextStyle(
                                                fontSize: 17,
                                                fontWeight: FontWeight.w700),
                                          ),
                                          Text(
                                            '${emailController.text}',
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.person,
                                        color: Colors.grey,
                                      ),
                                      Expanded(
                                        child: InputFormField(
                                          enabled: isEdited,
                                          controller: firstNameController,
                                          obscure: false,
                                          label: 'First name',
                                          textCapitalization:
                                              TextCapitalization.words,
                                          keyboardType: TextInputType.text,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return "Please enter a valid name";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                      SizedBox(width: 5),
                                      Expanded(
                                        child: InputFormField(
                                          enabled: isEdited,
                                          controller: lastNameController,
                                          obscure: false,
                                          label: 'Last name',
                                          textCapitalization:
                                              TextCapitalization.words,
                                          keyboardType: TextInputType.text,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return "Please enter a valid name";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.event,
                                        color: Colors.grey,
                                      ),
                                      Expanded(
                                        child: InkWell(
                                          onTap: () async {
                                            if (isEdited) {
                                              var chosenDate =
                                                  await userController.pickDob(
                                                      context, 'Date of Birth');
                                              print(chosenDate);
                                              if (chosenDate != null) {
                                                setState(() {
                                                  dobController.text =
                                                      DateFormat('yyyy-MM-dd')
                                                          .format(chosenDate)
                                                          .toString();
                                                });
                                              }
                                            }
                                          },
                                          child: InputFormField(
                                            enabled: false,
                                            controller: dobController,
                                            obscure: false,
                                            label: 'Date of birth',
                                            textCapitalization:
                                                TextCapitalization.none,
                                            keyboardType: TextInputType.phone,
                                            validator: (value) {
                                              if (value.isEmpty) {
                                                return "Please enter a valid date";
                                              }
                                              return null;
                                            },
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 5),
                                      Expanded(
                                        child: InkWell(
                                          onTap: () {
                                            genderOption(context);
                                          },
                                          child: InputFormField(
                                            enabled: false,
                                            controller: genderController,
                                            obscure: false,
                                            label: 'Gender',
                                            textCapitalization:
                                                TextCapitalization.words,
                                            keyboardType: TextInputType.text,
                                            suffixIcon: Icon(Icons.expand_more),
                                            validator: (value) {
                                              if (value.isEmpty) {
                                                return "Please enter a valid gender";
                                              }
                                              return null;
                                            },
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.location_city_rounded,
                                        color: Colors.grey,
                                      ),
                                      Expanded(
                                        child: InputFormField(
                                          enabled: isEdited,
                                          controller: addressController,
                                          obscure: false,
                                          label: 'Address',
                                          textCapitalization:
                                              TextCapitalization.words,
                                          keyboardType:
                                              TextInputType.streetAddress,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return "Please enter a valid address";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                      Expanded(
                                        child: InkWell(
                                          onTap: () {
                                            isEdited
                                                ? _showTerminalOption()
                                                : print('lll');
                                          },
                                          child: InputFormField(
                                            enabled: false,
                                            controller: locationController,
                                            obscure: false,
                                            label: 'Select a location',
                                            textCapitalization:
                                                TextCapitalization.words,
                                            keyboardType:
                                                TextInputType.streetAddress,

                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.call,
                                        color: Colors.grey,
                                      ),
                                      Expanded(
                                        child: InputFormField(
                                          enabled: isEdited,
                                          controller: phoneController,
                                          obscure: false,
                                          label: 'Phone number',
                                          textCapitalization:
                                              TextCapitalization.none,
                                          keyboardType: TextInputType.phone,
                                          suffixIcon: phoneController
                                                  .text.isEmpty
                                              ? Text('')
                                              : (phoneController
                                                          .text.isNotEmpty &&
                                                      phoneController.text
                                                          .startsWith('0') &&
                                                      phoneController
                                                              .text.length ==
                                                          11)
                                                  ? Icon(
                                                      Icons.done,
                                                      color: Colors.greenAccent,
                                                    )
                                                  : Icon(
                                                      Icons.close,
                                                      color: Colors.redAccent,
                                                    ),
                                          validator: (value) {
                                            if (value.isEmpty ||
                                                !value.startsWith('0') ||
                                                value.length != 11) {
                                              return "Please enter a valid phone number";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(children: [
                                    Icon(
                                      Icons.assignment_ind,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        onTap: () {
                                          // if (identityNumberController.text ==
                                          //     '')
                                          idOption(context);
                                        },
                                        child: InputFormField(
                                          controller: identityController,
                                          obscure: false,
                                          enabled: false,
                                          label: 'Identity Type',
                                          textCapitalization:
                                              TextCapitalization.words,
                                          keyboardType: TextInputType.text,
                                          suffixIcon: Icon(Icons.expand_more),
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return "Please select a valid mean of identification";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: InputFormField(
                                        enabled: isEdited,
                                        controller: identityNumberController,
                                        obscure: false,
                                        label: 'Identity number',
                                        textCapitalization:
                                            TextCapitalization.characters,
                                        keyboardType: TextInputType.text,
                                      ),
                                    ),
                                  ]),
                                  Row(children: [
                                    Icon(
                                      Icons.event,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        onTap: () async {
                                          if (isEdited) {
                                            var chosenDate =
                                                await userController.pickDate(
                                                    context, 'ID Issued Date');
                                            print(chosenDate);
                                            if (chosenDate != null) {
                                              setState(() {
                                                issueDateCOntroller.text =
                                                    DateFormat('yyyy-MM-dd')
                                                        .format(chosenDate)
                                                        .toString();
                                              });
                                            }
                                          }
                                        },
                                        child: InputFormField(
                                          enabled: false,
                                          controller: issueDateCOntroller,
                                          obscure: false,
                                          label: 'ID Issued Date',
                                          textCapitalization:
                                              TextCapitalization.words,
                                          keyboardType: TextInputType.text,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return "Please enter a valid date";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        onTap: () async {
                                          if (isEdited) {
                                            var chosenDate =
                                                await userController.pickDate(
                                                    context, 'Expiry Date');
                                            print(chosenDate);
                                            if (chosenDate != null) {
                                              setState(() {
                                                expiryDateCOntroller.text =
                                                    DateFormat('yyyy-MM-dd')
                                                        .format(chosenDate)
                                                        .toString();
                                              });
                                            }
                                          }
                                        },
                                        child: InputFormField(
                                          enabled: false,
                                          controller: expiryDateCOntroller,
                                          obscure: false,
                                          label: 'ID Expiry Date',
                                          textCapitalization:
                                              TextCapitalization.none,
                                          keyboardType: TextInputType.phone,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return "Please enter a valid date";
                                            }
                                            return null;
                                          },
                                        ),
                                      ),
                                    ),
                                  ]),
                                  SizedBox(height: 10),
                                  Center(
                                    child: InkWell(
                                        onTap: () async {
                                          if (isEdited) {
                                            var selectedImage =
                                                await PickImage.openCamera();
                                            print(selectedImage);
                                            if (selectedImage != null) {
                                              setState(() {
                                                _idImage = selectedImage;
                                              });
                                            }
                                          }
                                        },
                                        child: _idImage == null
                                            ? Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Icon(Icons.file_upload),
                                                  SizedBox(width: 10),
                                                  Text('Upload ID photo',
                                                      style: TextStyle(
                                                          color: Colors.black54,
                                                          fontSize: 15,
                                                          fontWeight:
                                                              FontWeight.w700)),
                                                ],
                                              )
                                            : Container(
                                                height: 100,
                                                width: 120,
                                                decoration: BoxDecoration(
                                                    border: Border.all(),
                                                    image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image:
                                                          FileImage(_idImage!),
                                                    )),
                                              )),
                                  ),
                                  SizedBox(height: 30),
                                  !isEdited
                                      ? Buttons.authButton(
                                          context: context,
                                          onTap: () {
                                            setState(() {
                                              isEdited = true;
                                            });
                                            print('updating');
                                          },
                                          title: 'Edit Profile')
                                      : Buttons.authButton(
                                          context: context,
                                          onTap: () {
                                            isLoading
                                                ? print('....')
                                                : updateUser();
                                          },
                                          title: isLoading
                                              ? 'Saving'
                                              : 'Save Profile'),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<String> genders = ['Male', 'Female'];

  Future genderOption(BuildContext context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SingleChildScrollView(
        child: Container(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          height: MediaQuery.of(context).size.height * 0.23,
          decoration: BoxDecoration(
            color: Colors.transparent,
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
                  color: Theme.of(context).scaffoldBackgroundColor),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(25.0),
                      child: InkWell(
                        onTap: () {
                          Get.back();
                        },
                        child: Container(
                          width: 50,
                          height: 4,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children:
                                List<Widget>.generate(genders.length, (index) {
                              return new ListTile(
                                onTap: () => _selectGender(genders[index]),
                                title: Text(
                                  genders[index],
                                  softWrap: true,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight:
                                        genderController.text == genders[index]
                                            ? FontWeight.w600
                                            : FontWeight.w500,
                                  ),
                                ),
                                trailing:
                                    genderController.text == genders[index]
                                        ? Icon(Icons.circle,
                                            size: 15, color: Colors.green)
                                        : Text(''),
                              );
                            }),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _selectGender(String option) {
    Get.back();
    setState(() {
      genderController.text = option;
    });
  }

  List<String> idType = [
    'Passport',
    'DriverLicense',
    'NationalID',
    'Social Security',
    'BVN',
    'Voter\'s Card',
  ];
  List<String> idIndex = ['1', '2', '3', '4', '5', '6'];

  Future idOption(BuildContext context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SingleChildScrollView(
        child: Container(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          height: MediaQuery.of(context).size.height * 0.4,
          decoration: BoxDecoration(
            color: Colors.transparent,
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
                  color: Theme.of(context).scaffoldBackgroundColor),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(25.0),
                      child: InkWell(
                        onTap: () {
                          Get.back();
                        },
                        child: Container(
                          width: 50,
                          height: 4,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children:
                                List<Widget>.generate(idType.length, (index) {
                              return new ListTile(
                                onTap: () => _selectIdentity(
                                    idType[index], idIndex[index]),
                                title: Text(
                                  idType[index],
                                  softWrap: true,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight:
                                        identityController.text == idType[index]
                                            ? FontWeight.w600
                                            : FontWeight.w500,
                                  ),
                                ),
                                trailing:
                                    identityController.text == idType[index]
                                        ? Icon(Icons.circle,
                                            size: 15, color: Colors.green)
                                        : Text(''),
                              );
                            }),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  String identityIndex = '';

  void _selectIdentity(option, id) {
    Get.back();
    setState(() {
      identityController.text = option;
      identityIndex = id;
    });
  }

  bool isLoading = false;

  changeLoadingState() {
    setState(() {
      isLoading = !isLoading;
    });
  }

  updateUser() async {
    if (await InternetUtils.checkConnectivity()) {
      if (_formKey.currentState!.validate()) {
        changeLoadingState();
        var response = await UserServices.updateUser(
            email: emailController.text,
            userId: userId,
            locationid: userId,
            firstName: firstNameController.text,
            dateOfBirth: dobController.text,
            token: token,
            address: addressController.text,
            idIssueDate: issueDateCOntroller.text,
            lastName: lastNameController.text,
            gender: genderController.text,
            idExpireDate: expiryDateCOntroller.text,
            phoneNumber: phoneController.text,
            identificationType: identityController.text,
            identificationCode: identityNumberController.text,
            photoId: _idImage,
            picture: _image);
        print(response);
        if (response is String) {
          changeLoadingState();
          Dialogs.showErrorSnackBar('Error', response);
        } else {
          var profile = await AuthenticationService.getProfile(token);
          print(profile);
          if (profile is String) {
            changeLoadingState();

            Dialogs.showErrorSnackBar('Error!', profile);
          } else if (response['shortDescription'] != 'SUCCESS') {
            changeLoadingState();

            Dialogs.showErrorSnackBar('Error!', response['shortDescription']);
          } else {
            await userController.setUserDetails(profile);
            Get.back();
            Dialogs.showNoticeSnackBar('Congratulation!',
                'Your profile has been updated successfully');
          }
        }
      } else {
        Dialogs.showErrorSnackBar(
            'Error', 'Ensure all required fields are filled');
      }
    }
  }
}
