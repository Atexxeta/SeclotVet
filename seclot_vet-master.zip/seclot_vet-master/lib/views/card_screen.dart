import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/views/homepage.dart';
import 'package:seclot_vet/widgets/button.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import 'input_fields.dart';

class PaymentCard extends StatefulWidget {
  const PaymentCard({Key? key}) : super(key: key);

  @override
  _PaymentCardState createState() => _PaymentCardState();
}

class _PaymentCardState extends State<PaymentCard> {
  final TextEditingController cardNumberController = TextEditingController();
  final TextEditingController cardHolderNameController =
      TextEditingController();
  final TextEditingController cvvController = TextEditingController();
  final TextEditingController expiryController = TextEditingController();

  String name = '';
  String cvv = '';
  String expiry = '';
  String cardNumber = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Column(
        children: [
          // SizedBox(height: 50),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 38, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      Icons.west,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                ),
                Text(''),
                SizedBox(width: 30),
              ],
            ),
          ),

          SizedBox(height: 25),
          Expanded(
            child: Container(
              // height: MediaQuery.of(context).size.height * 0.8,
              decoration: BoxDecoration(
                color: Theme.of(context).accentColor,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 20, 0, 25),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            'Card Detail',
                            style: GoogleFonts.roboto(
                                fontSize: 18, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(30))),
                      padding:
                          EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              height: 185,
                              decoration: BoxDecoration(
                                color: Colors.black87,
                                border: Border.all(
                                    color: Colors.grey.withOpacity(0.4),
                                    width: 0.5),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(20, 15, 20, 15),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Seclot Vet Payment',
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w900),
                                    ),
                                    Text(
                                      cardNumberController.text,
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                          letterSpacing: 1.2,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          children: [
                                            Text('Expiry'),
                                            Text(
                                              expiryController.text,
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  color: Colors.white,
                                                  letterSpacing: 0.4,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                          ],
                                        ),
                                        Column(
                                          children: [
                                            Text('CVV'),
                                            Text(
                                              cvvController.text,
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  color: Colors.white,
                                                  letterSpacing: 0.4,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    Text(
                                      cardHolderNameController.text,
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.white,
                                          letterSpacing: 0.7,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                            InputFormField(
                              controller: cardNumberController,
                              obscure: false,
                              label: 'Card Number',
                              textCapitalization: TextCapitalization.none,
                              keyboardType: TextInputType.phone,
                              onChanged: (value) {
                                setState(() {
                                  cardNumber = cardNumberController.text;
                                });
                              },
                              validator: (value) {
                                if (value.isEmpty) {
                                  return "Card number cannot be empty";
                                }
                                return null;
                              },
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: InputFormField(
                                    controller: expiryController,
                                    obscure: false,
                                    label: 'MM/YY',
                                    textCapitalization: TextCapitalization.none,
                                    keyboardType: TextInputType.phone,
                                    onChanged: (value) {
                                      setState(() {
                                        expiry = expiryController.text;
                                      });
                                    },
                                    validator: (value) {
                                      if (value.isEmpty) {
                                        return "Card number cannot be empty";
                                      }
                                      return null;
                                    },
                                  ),
                                ),
                                Expanded(
                                  child: InputFormField(
                                    controller: cvvController,
                                    obscure: false,
                                    label: 'CVV',
                                    textCapitalization: TextCapitalization.none,
                                    keyboardType: TextInputType.phone,
                                    onChanged: (value) {
                                      setState(() {
                                        cvv = cvvController.text;
                                      });
                                    },
                                    validator: (value) {
                                      if (value.isEmpty) {
                                        return "Card number cannot be empty";
                                      }
                                      return null;
                                    },
                                  ),
                                ),
                              ],
                            ),
                            InputFormField(
                              controller: cardHolderNameController,
                              obscure: false,
                              label: 'Card Holder\'s Name',
                              textCapitalization: TextCapitalization.words,
                              keyboardType: TextInputType.text,
                              onChanged: (value) {
                                setState(() {
                                  name = cardHolderNameController.text;
                                });
                              },
                              validator: (value) {
                                if (value.isEmpty) {
                                  return "Card holder\'s name cannot be empty";
                                }
                                return null;
                              },
                            ),
                            SizedBox(height: 10),
                            Center(
                              child: InkWell(
                                onTap: () {
                                  // Get.toNamed(Routes.signUp, arguments: {'type': type});
                                },
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                          text: 'Card details are protected',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 13,
                                          )),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 20),
                            Buttons.authButton(
                                context: context,
                                onTap: () {
                                  Dialogs.showSuccessDialog(
                                    context: context,
                                    actionText: 'Got back home',
                                    message: 'Top up Successful!',
                                    action: () {
                                      Get.offAll(() => HomeScreen());
                                    },
                                  );
                                },
                                title: 'Continue'),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
