import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:seclot_vet/controllers/user_controller.dart';
import 'package:seclot_vet/services/web_services.dart';
import 'package:seclot_vet/widgets/dialogs.dart';

import 'input_fields.dart';

class CompletedVetScreen extends StatefulWidget {
  const CompletedVetScreen({Key? key}) : super(key: key);

  @override
  _CompletedVetScreenState createState() => _CompletedVetScreenState();
}

class _CompletedVetScreenState extends State<CompletedVetScreen> {
  UserController userController = Get.find();
  String token = '';
  String clientId = '';
  var completedVet;
  var allVet;
  var searchVet;
  final searchController = TextEditingController();
  bool isSearch = false;

  @override
  void initState() {
    token = userController.getToken();
    clientId = userController.getUser().userId;
    print(userController.getLogo());
    boot();
    super.initState();
  }

  boot() async {
    getVets();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  getVets() async {
    var response = await WebServices.getVets(token, clientId);
    // print(response);
    if (response['shortDescription'] != 'SUCCESS') {
      Dialogs.showErrorSnackBar('Error Fetching', response);
    } else {
      setState(() {
        var receivingVet = response['object']['items'];
        allVet = receivingVet.where((i) => i['vetteeStatus'] != 4).toList();
        print('allVet');
        print(allVet.length);
      });
    }
  }

  search(value) {
    if (value.length > 3) {
      print(value);
      setState(() {
        isSearch = true;
        var list = allVet
            .where((element) =>
                (element['referenceCode']
                        .toString()
                        .toLowerCase()
                        .removeAllWhitespace
                        .contains(value
                            .toString()
                            .toLowerCase()
                            .removeAllWhitespace) ||
                    '${element['vetteeFirstName']} ${element['vetteeLastName']}'
                        .toString()
                        .toLowerCase()
                        .removeAllWhitespace
                        .contains(value
                            .toString()
                            .toLowerCase()
                            .removeAllWhitespace)) &&
                element != null)
            .toList();
        searchVet = list;
        print('list');
        print(searchVet);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    completedVet = isSearch == true ? searchVet : allVet;
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
          setState(() {
            isSearch = false;
            searchController.text = '';
          });
        },
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 35, 10, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {
                      Get.back();
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.west,
                        color: Colors.white,
                        size: 25,
                      ),
                    ),
                  ),
                  Text(
                    'Submitted Vets',
                    style: GoogleFonts.roboto(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white),
                  ),
                  SizedBox(width: 30),
                ],
              ),
            ),
            SizedBox(height: 5),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).accentColor,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                ),
                child: Column(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(30))),
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(0, 0, 15, 0),
                          child: Column(
                            children: [
                              Padding(
                                padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
                                child: searchBox(
                                    context: context,
                                    labelText: 'Search by Ref or name',
                                    onChanged: (value) => search(value),
                                    searchController: searchController,
                                    close: () {
                                      setState(() {
                                        isSearch = false;
                                        searchController.text = '';
                                      });
                                    }),
                              ),
                              Expanded(
                                child: completedVet == null
                                    ? Center(
                                        child: CircularProgressIndicator(
                                        color: Theme.of(context).primaryColor,
                                      ))
                                    : ListView.builder(
                                        padding: EdgeInsets.all(0),
                                        itemCount: completedVet.length,
                                        itemBuilder: (context, index) {
                                          var item = completedVet[index];
                                          return completeVet(
                                            context: context,
                                            title:
                                                '${item['vetteeFirstName']} ${item['vetteeLastName']}',
                                            subtitle: item['referenceCode'],
                                            picture: item['picture'],
                                            status: item['vetteeStatus'] == 1
                                                ? 'Vet in Progress'
                                                : item['vetteeStatus'] == 2
                                                    ? 'In Transit'
                                                    : item['vetteeStatus'] == 3
                                                        ? 'Available'
                                                        : item['vetteeStatus'] ==
                                                                4
                                                            ? 'Concluded'
                                                            : 'Pending',
                                            color: item['vetteeStatus'] == 1
                                                ? Colors.purpleAccent
                                                : item['vetteeStatus'] == 2
                                                    ? Colors.blueAccent
                                                    : item['vetteeStatus'] == 3
                                                        ? Colors.indigo
                                                        : item['vetteeStatus'] ==
                                                                4
                                                            ? Colors.green
                                                            : Colors.orange,
                                            payment: item['paymentStatus'] == 0
                                                ? 'Pending'
                                                : item['paymentStatus'] == 1
                                                    ? 'Paid'
                                                    : item['paymentStatus'] == 2
                                                        ? 'Declined'
                                                        : 'Approved',
                                            email: item['email'] == ''
                                                ? 'N/A'
                                                : item['email'],
                                            phoneNumber: item['phoneNumber'],
                                            address: item['address'] ?? 'N/A',
                                          );
                                        }),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  completeVet(
      {context,
      title,
      subtitle,
      status,
      picture,
      payment,
      phoneNumber,
      address,
      color,
      email}) {
    return Container(
      margin: EdgeInsets.only(bottom: 5),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 5, 0, 5),
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            collapsedTextColor: Colors.black,
            textColor: Colors.black,
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            key: PageStorageKey<String>(title),
            title: Row(
              children: [
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      fit: BoxFit.fitHeight,
                      image: NetworkImage((picture == null ||
                              picture == '' ||
                              picture == 'null')
                          ? userController.getLogo()
                          : picture),
                      // image: NetworkImage(userController.getLogo())),
                    ),
                  ),
                ),
                SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                      ),
                      Text(subtitle)
                    ],
                  ),
                ),
              ],
            ),
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(left: 35.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 5),
                    detailWidget('Phone Number', '$phoneNumber'),
                    SizedBox(height: 5),
                    detailWidget('Email', '$email'),
                    SizedBox(height: 5),
                    detailWidget('Address', '$address'),
                    SizedBox(height: 5),
                    Row(
                      children: [
                        Expanded(
                          child: detailWidget('Payment Status', '$payment'),
                        ),
                        SizedBox(width: 5),
                        statusIndicator("$status", color),
                      ],
                    ),
                    SizedBox(height: 5),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

detailWidget(title, desc) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(0, 5, 5, 5),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(color: Colors.black54, fontSize: 13),
        ),
        SizedBox(height: 3),
        Text(desc, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      ],
    ),
  );
}

statusIndicator(status, color) {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5),
      color: color,
    ),
    child: Padding(
      padding: const EdgeInsets.fromLTRB(15, 8, 15, 8),
      child: Text(status.toString(),
          style: TextStyle(
              fontSize: 15, fontWeight: FontWeight.w600, color: Colors.white)),
    ),
  );
}
