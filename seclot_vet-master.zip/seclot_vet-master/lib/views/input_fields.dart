import 'package:flutter/material.dart';

class InputFormField extends StatelessWidget {
  const InputFormField({
    this.suffixIcon,
    this.prefixIcon,
    this.onSaved,
    this.validator,
    this.obscure = false,
    this.onChanged,
    this.enabled,
    this.controller,
    this.focusNode,
    this.label,
    this.textCapitalization=TextCapitalization.none,
    this.keyboardType,
    this.inputFormatters,
  });

  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final onSaved;
  final  onChanged;
  final  validator;
  final  focusNode;
  final bool? enabled;
  final TextEditingController? controller;
  final bool obscure;
  final String? label;
  final TextCapitalization textCapitalization;
  final TextInputType? keyboardType;
  final inputFormatters;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 8),
      child: TextFormField(
        inputFormatters: inputFormatters,
        enabled: enabled,
        controller: controller,
        keyboardType: keyboardType,
        style: TextStyle(
          fontSize: 13,
        ),
        textCapitalization: textCapitalization,
        validator: validator,
        onChanged: onChanged,
        onSaved: onSaved,
        obscureText: obscure ,
        focusNode: focusNode,
        decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xFFE5E5EF).withOpacity(0.2),
          border: InputBorder.none,
          enabledBorder: buildOutlineBorder(context),
          disabledBorder: buildOutlineBorder(context),
          focusedBorder: buildOutlineBorderless(context),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(35),
            borderSide: BorderSide(color: Colors.redAccent),
          ),
          focusedErrorBorder: buildOutlineBorderless(context),
          suffixIcon: suffixIcon,
          prefixIcon: prefixIcon,
          labelText: label,
          labelStyle: TextStyle(fontSize: 13, color: Colors.grey),
          contentPadding:
          EdgeInsets.symmetric(vertical: 20.0, horizontal: 25.0),
        ),
      ),
    );
  }
}

OutlineInputBorder buildOutlineBorderless(BuildContext context) {
  return OutlineInputBorder(
      borderSide: BorderSide(color: Colors.grey, width: 0.6),
      borderRadius: BorderRadius.all(Radius.circular(35)));
}

OutlineInputBorder buildOutlineBorder(BuildContext context) {
  return OutlineInputBorder(
    borderSide: BorderSide(
      color: Colors.grey.withOpacity(0.5), width: 0.4
    ),
    borderRadius: BorderRadius.all(
      Radius.circular(35),
    ),
  );
}

Padding searchBox(
    { context,
      searchController,
      labelText,
      onChanged,
      onTap,
      onEditingComplete,
      onFieldSubmitted,
      close}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10.0),
    child: TextFormField(
      controller: searchController,
      keyboardType: TextInputType.text,
      onChanged: onChanged,
      onTap: onTap,
      onEditingComplete: onEditingComplete,
      onFieldSubmitted: onFieldSubmitted,
      style: TextStyle(fontSize: 12, color: Colors.black87),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: InputBorder.none,
        enabledBorder: buildOutlineBorderless(context),
        focusedBorder: buildOutlineBorderless(context),
        prefixIcon: Icon(Icons.search, size: 20),
        suffixIcon: InkWell(onTap: close, child: Icon(Icons.cancel, size: 20)),
        labelText: labelText ?? 'Search',
        labelStyle: TextStyle(fontSize: 12, color: Colors.grey),
        contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
      ),
    ),
  );
}
