import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'routes.dart';
import 'views/splash_screen.dart';

void _enablePlatformOverrideForDesktop() {
  if (!kIsWeb && (Platform.isWindows || Platform.isLinux)) {
    debugDefaultTargetPlatformOverride = TargetPlatform.fuchsia;
  }
}


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  _enablePlatformOverrideForDesktop();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]).then(
    (_) async {
      runApp(
        MyApp(),
      );
    },
  );
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      defaultTransition: Transition.fadeIn,
      title: 'Seclot Vet',
      theme: ThemeData(
        fontFamily: 'Roboto',
        primaryColor: Color(0xFF1C1C1C),
        accentColor: Color(0xFF555555),
        scaffoldBackgroundColor: Color(0xFFE6E6E6),
        buttonColor: Color(0xFF666666),
      ),
      getPages: Routes.getXRoutes(),
      home: SplashScreen(),
    );
  }
}

class PickImage {
  static openCamera() async {
    ImagePicker imagePicker = new ImagePicker();
    XFile? pickedFile = await imagePicker.pickImage(
        source: ImageSource.camera,
        imageQuality: 50,
        maxHeight: 500,
        maxWidth: 500);

    if (pickedFile != null) {
      File file = File(pickedFile.path);
      return file;
    }

    return null;
  }

  static openGallery() async {
    ImagePicker imagePicker = new ImagePicker();
    XFile? pickedFile = await imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
        maxHeight: 500,
        maxWidth: 500);

    if (pickedFile != null) {
      File file = File(pickedFile.path);
      return file;
    }

    return null;
  }
}
