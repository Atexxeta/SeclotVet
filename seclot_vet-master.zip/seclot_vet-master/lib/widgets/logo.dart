import 'package:flutter/material.dart';

logo(){
  return Padding(
    padding: const EdgeInsets.all(12.0),
    child: Image.asset('assets/images/seclot_logo.png',height: 25),
  );
}