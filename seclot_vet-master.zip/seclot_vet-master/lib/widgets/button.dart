import 'package:flutter/material.dart';

class
    Buttons{
  static authButton({ context, onTap, title}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 35.0),
      child: Center(
        child: InkWell(
          onTap: onTap,
          child: Container(
              height: 53,
              width: 223,
              decoration: BoxDecoration(
                boxShadow: <BoxShadow>[
                  BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      offset: Offset(0.2, 0.3))
                ],
                borderRadius: BorderRadius.circular(35),
                color: Theme.of(context).primaryColor,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 15.0, vertical: 15),
                child: Center(
                  child: Text(
                    title,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: Colors.white),
                  ),
                ),
              )),
        ),
      ),
    );
  }

  static    smallButton({context, action, actionText}) {
    return InkWell(
      onTap: action,
      child: Container(
        decoration: BoxDecoration(
            color: Theme.of(context).primaryColor,
            borderRadius: BorderRadius.circular(30)),
        padding: const EdgeInsets.all(13.0),
        child: Center(
          child: Text(
            actionText,
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }

}