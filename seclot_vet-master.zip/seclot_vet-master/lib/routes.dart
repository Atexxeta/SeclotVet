
import 'package:get/get.dart';
import 'views/homepage.dart';
import 'views/login_screen.dart';
import 'views/onboarding_screen.dart';
import 'views/otp.dart';
import 'views/register_screen.dart';
import 'views/splash_screen.dart';

class Routes{
  static const String splashScreen = '/splash-page';
  static const String welcomeScreen = '/welcome-page';
  static const String welcomeScreen2 = '/welcome-page2';
  static const String activateAccount = '/activate-page';
  static const String register = '/signUp-page';
  static const String signUp3 = '/signUp-page3';
  static const String changePassword = '/changePassword-page';
  static const String resetPassword = '/resetPassword-page';
  static const String congratulation = '/congratulation-page3';
  static const String signIn = '/signIn-page';
  static const String dashboard = '/dashboard-page';
  static const String notification = '/notification-page';
  static const String wallet = '/wallet-page';
  static const String buyCrypto = '/buyCrypto-page';
  static const String paymentMethod = '/paymentMethod-page';
  static const String walletDetail = '/walletDetail-page';
  static const String sendReceive = '/sendReceive-page';
  static const String sendReceiveSuccess = '/sendReceiveSuccess-page';
  static const String transactionSuccess = '/transactionSuccess-page';
  static const String confirmTransaction = '/confirmTransaction-page';
  static const String activity = '/activity-page';
  static const String activityDetails = '/activityDetails-page';
  static const String feedback = '/feedback-page';
  static const String loanIntro1 = '/loanIntro1-page';
  static const String loanIntro2 = '/loanIntro2-page';
  static const String withdrawal = '/withdrawal-page';
  static const String bPay = '/bPay-page';
  static const String topUpSavings = '/topUpSavings-page';
  static const String settings = '/settings-page';
  static const String investment = '/investment-page';
  static const String newInvestment = '/newInvestment-page';
  static const String savings = '/savings-page';
  static const String utilityBills = '/utilityBills-page';
  static const String referral = '/referral-page';
  static const String myInvestment = '/myInvestment-page';
  static const String loan = '/loan-page';
  static const String profile = '/profile-page';
  static const String fundWallet = '/fundWallet-page';
  static const String newSaving = '/newSaving-page';
  static const String savingPurpose = '/savingPurpose-page';
  static const String mySavings = '/mySavings-page';
  static const String comingSoon = '/comingSoon-page';
  static const String globalRemittance = '/selectBank-page';
  static const String investmentDetail = '/investmentDetail-page';
  static const String cryptoLoanAmount = '/cryptoLoanAmount-page';
  static const String loanDuration = '/loanDuration-page';
  static const String loanSuccess = '/loanSuccess-page';
  static const String loanBreakdown = '/loanBreakdown-page';
  static const String payBack = '/payBack-page';
  static const String walletLists = '/cryptoLoan-page';
  static const String loanAmount = '/loanAmount-page';
  static const String savingDetails = '/savingDetails-page';
  static const String savingTime = '/savingTime-page';
  static const String confirmSaving = '/confirmSaving-page';
  static const String savingAmount = '/savingAmount-page';
  static const String mySavingDetail = '/mySavingDetail-page';
  static const String savingFrequency = '/savingFrequency-page';
  static const String savingMethod = '/savingMethod-page';
  static const String savingTargetAmount = '/savingTargetAmount-page';
  static const String savingDuration = '/savingDuration-page';
  static const String otherBankDetails = '/otherBankDetails-page';
  static const String sendOfflineCrypto = '/sendOfflineCrypto-page';
  static const String bankConfirmation = '/bankConfirmation-page';
  static const String withdrawalSuccess = '/withdrawalSuccess-page';
  static const String dataSub = '/dataSub-page';
  static const String smileData = '/smileData-page';
  static const String electricity = '/electricity-page';
  static const String cableTv = '/cableTv-page';
  static const String changePin = '/changePin-page';
  static const String newPin = '/newPin-page';
  static const String topUpAmount = '/topUpAmount-page';
  static const String myInvestmentDetails = '/myInvestmentDetails-page';
  static const String topUpInvestment = '/topUpInvestment-page';
  static const String investmentTop = '/investmentTop-page';
  static const String savingsTop = '/savingsTop-page';
  static const String noInternet = '/noInternet-page';


  static List<GetPage> getXRoutes() {
    return [
      GetPage(name: Routes.splashScreen, page: () => SplashScreen()),
      GetPage(name: Routes.welcomeScreen, page: () => WelcomeScreen()),
      // GetPage(name: Routes.welcomeScreen2, page: () => WelcomeScreen2()),
      GetPage(name: Routes.register, page: () => RegisterScreen()),
      GetPage(name: Routes.activateAccount, page: () => OtpScreen()),
      // GetPage(name: Routes.signUp3, page: () => SignUpScreen3()),
      // GetPage(name: Routes.changePassword, page: () => ChangePassword()),
      // GetPage(name: Routes.resetPassword, page: () => ResetPassword()),
      // GetPage(name: Routes.congratulation, page: () => Congratulation()),
      GetPage(name: Routes.signIn, page: () => LogInScreen()),
      GetPage(name: Routes.dashboard, page: () => HomeScreen()),
      // GetPage(name: Routes.notification, page: () => Notification()),
      // GetPage(name: Routes.wallet, page: () => WalletScreen()),
      // GetPage(name: Routes.buyCrypto, page: () => BuySellCrpto()),
      // GetPage(name: Routes.sendReceive, page: () => SendReceive()),
      // GetPage(name: Routes.activity, page: () => Activity()),
      // GetPage(name: Routes.activityDetails, page: () => Receipt()),
      // GetPage(name: Routes.feedback, page: () => Feedback()),
      // GetPage(name: Routes.loanIntro1, page: () => LoanIntro1()),
      // GetPage(name: Routes.loanIntro2, page: () => LoanIntro2()),
      // GetPage(name: Routes.loan, page: () => Loan()),
      // GetPage(name: Routes.bPay, page: () => BPayAccount()),
      // GetPage(name: Routes.topUpSavings, page: () => TopUpSaving()),
      // GetPage(name: Routes.settings, page: () => Settings()),
      // GetPage(name: Routes.investment, page: () => InvestmentWelcome()),
      // GetPage(name: Routes.newInvestment, page: () => InvestmentDashboard()),
      // GetPage(name: Routes.savings, page: () => Savings()),
      // GetPage(name: Routes.utilityBills, page: () => UtilityBills()),
      // GetPage(name: Routes.referral, page: () => Referral()),
      // GetPage(name: Routes.myInvestment, page: () => MyInvestment()),
      // GetPage(name: Routes.profile, page: () => Profile()),
      // GetPage(name: Routes.fundWallet, page: () => BPayWallet()),
      // GetPage(name: Routes.newSaving, page: () => SavingPlan()),
      // GetPage(name: Routes.savingPurpose, page: () => SavingPurpose()),
      // GetPage(name: Routes.mySavings, page: () => MySavings()),
      // GetPage(name: Routes.savingTargetAmount, page: () => SavingTargetAmount()),
      // GetPage(name: Routes.comingSoon, page: () => ComingSoon()),
      // GetPage(name: Routes.globalRemittance, page: () => SelectBank()),
      // GetPage(name: Routes.investmentDetail, page: () => InvestmentDetail()),
      // GetPage(name: Routes.cryptoLoanAmount, page: () => CryptoLoanAmount()),
      // GetPage(name: Routes.loanDuration, page: () => LoanDuration()),
      // GetPage(name: Routes.loanSuccess, page: () => LoanSuccess()),
      // GetPage(name: Routes.loanBreakdown, page: () => LoanBreakdown()),
      // GetPage(name: Routes.payBack, page: () => PayBack()),
      // GetPage(name: Routes.walletLists, page: () => MyCryptoWallet()),
      // GetPage(name: Routes.loanAmount, page: () => LoanAmount()),
      // GetPage(name: Routes.savingDetails, page: () => SavingDetails()),
      // GetPage(name: Routes.savingTime, page: () => SavingTime()),
      // GetPage(name: Routes.savingAmount, page: () => SavingAmount()),
      // GetPage(name: Routes.savingFrequency, page: () => SavingFrequency()),
      // GetPage(name: Routes.savingMethod, page: () => SavingMethod()),
      // GetPage(name: Routes.mySavingDetail, page: () => MySavingDetails()),
      // GetPage(name: Routes.savingDuration, page: () => SavingDuration()),
      // GetPage(name: Routes.otherBankDetails, page: () => OtherBankDetails()),
      // GetPage(name: Routes.dataSub, page: () => DataSub()),
      // GetPage(name: Routes.electricity, page: () => Electricity()),
      // GetPage(name: Routes.cableTv, page: () => CableTv()),
      // GetPage(name: Routes.changePin, page: () => ChangePin()),
      // GetPage(name: Routes.newPin, page: () => NewPin()),
      // GetPage(name: Routes.topUpAmount, page: () => TopUpAmountBody()),
      // GetPage(name: Routes.myInvestmentDetails, page: () => MyInvestmentDetails()),
      // GetPage(name: Routes.topUpInvestment, page: () => TopUpInvestmentBody()),
      // GetPage(name: Routes.investmentTop, page: () => InvestmentTop()),
      // GetPage(name: Routes.savingsTop, page: () => SavingTop()),
      // GetPage(name: Routes.noInternet, page: () => SplashInternetCheck()),

    ];}
}