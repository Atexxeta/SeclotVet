package com.fursee.seclot_vet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
